<?php
	include 'assets/includes/inc_Session.php';

	$user_type_id	 = $_REQUEST["User_Type_ID"];
	$function_type = $_REQUEST["Function_Type"];
	$type					 = '';
	$values 			 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblUserTypes WHERE User_Type_ID = " . $user_type_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblUserTypes (
															User_Type_Desc, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["User_Type_Desc"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(User_Type_ID) as ID FROM tblUserTypes";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$user_type_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblUserTypes 
									SET 	 User_Type_Desc = '" . str_replace("'", "''", $_REQUEST["User_Type_Desc"]) . "', 
												 Active				  = "  . $_REQUEST["Active"] . "
									WHERE  User_Type_ID	  = "  . $user_type_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?User_Type_ID=' . $user_type_id;
	}
?>

<script>
	alert("User Type has been <?php echo($type) ?>");
	window.location = "manage_user_types.php<?php echo $values; ?>";
</script>