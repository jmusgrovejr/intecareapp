<?php
	include 'assets/includes/inc_Session.php';

	$service_time_id = $_REQUEST["Service_Time_ID"];
	$function_type 	 = $_REQUEST["Function_Type"];
	$type						 = '';
	$values				 	 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblServiceTime WHERE Service_Time_ID = " . $service_time_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblServiceTime (
															Service_Time_Value, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Service_Time_Value"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Service_Time_ID) as ID FROM tblServiceTime";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$service_time_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblServiceTime 
									SET 	 Service_Time_Value = '" . str_replace("'", "''", $_REQUEST["Service_Time_Value"]) . "', 
												 Active						 	= "  . $_REQUEST["Active"] . "
									WHERE  Service_Time_ID	 	= "  . $service_time_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Service_Time_ID=' . $service_time_id;
	}
?>

<script>
	alert("Service Time has been <?php echo($type) ?>");
	window.location = "manage_service_time.php<?php echo $values; ?>";
</script>