<?php
	include 'assets/includes/inc_Session.php';

	$user_id			 = $_REQUEST["User_ID"];
	$function_type = $_REQUEST["Function_Type"];
	$type					 = '';
	$values 			 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing user
		$sqlstmt = "DELETE FROM tblUsers WHERE User_ID = " . $user_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new contact_type
			$sqlstmt = "INSERT INTO tblUsers (
															User_Type_ID, 
															First_Name, 
															Last_Name, 
															User_Name, 
															User_Password, 
															Email_Address, 
															Last_Logon_Date, 
															Active) 
									VALUES (" . $_REQUEST['User_Type_ID'] . ", '"
														.	str_replace("'", "''", $_REQUEST["First_Name"]) . "', '" 
														.	str_replace("'", "''", $_REQUEST["Last_Name"]) . "', '" 
														. $_REQUEST["User_Name"] . "', '"
														. $_REQUEST["User_Password"] . "', '"
														. $_REQUEST["Email_Address"] . "', '"
														. date('Y-m-d') . "', "
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(User_ID) as ID FROM tblUsers";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$user_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing contact_type
			$sqlstmt = "UPDATE tblUsers 
									SET 	User_Type_ID 		=  " . $_REQUEST['User_Type_ID'] . ",
												First_Name 			= '" . str_replace("'", "''", $_REQUEST["First_Name"]) . "', 
												Last_Name 	  	= '" . str_replace("'", "''", $_REQUEST["Last_Name"]) . "', 
												User_Name 			= '" . $_REQUEST["User_Name"] . "', 
												Email_Address 	= '" . $_REQUEST["Email_Address"] . "', 
												Active					=  " . $_REQUEST["Active"] . "
									WHERE User_ID 				=  " . $user_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?User_ID=' . $user_id;
	}
?>

<script>
	alert("User has been <?php echo($type) ?>");
	window.location = "manage_users.php<?php echo $values; ?>";
</script>