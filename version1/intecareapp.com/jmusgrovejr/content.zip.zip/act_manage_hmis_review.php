<?php
	include 'assets/includes/inc_Session.php';

	$hmis_review_id = $_REQUEST["HMIS_Review_ID"];
	$function_type 	= $_REQUEST["Function_Type"];
	$type						= '';
	$values				 	= '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblHMISReview WHERE HMIS_Review_ID = " . $hmis_review_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblHMISReview (
															HMIS_Review_Value, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["HMIS_Review_Value"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(HMIS_Review_ID) as ID FROM tblHMISReview";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$hmis_review_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblHMISReview 
									SET 	 HMIS_Review_Value = '" . str_replace("'", "''", $_REQUEST["HMIS_Review_Value"]) . "', 
												 Active						 = "  . $_REQUEST["Active"] . "
									WHERE  HMIS_Review_ID	 	 = "  . $hmis_review_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?HMIS_Review_ID=' . $hmis_review_id;
	}
?>

<script>
	alert("HMIS Review has been <?php echo($type) ?>");
	window.location = "manage_hmis_review.php<?php echo $values; ?>";
</script>