<?php
	//header("Content-type: application/vnd.ms-excel");
	//header("Content-Disposition: attachment; filename=excel.xls");

	set_time_limit (0);
	$begin_date = $_REQUEST['Search_Begin_Date'];
	$end_date 	= $_REQUEST['Search_End_Date'];

	require_once 'PHPExcel/Classes/PHPExcel.php'; 
	require_once 'PHPExcel/Classes/PHPExcel/IOFactory.php';  

	// Create new PHPExcel object 
	$objPHPExcel = new PHPExcel();  
 
	/************************************************************************** 
	* Create a first sheet, representing cenpantico active providers data     *
	**************************************************************************/ 
	$objPHPExcel->setActiveSheetIndex(0);

	// include the column headers	
	include 'assets/includes/inc_PHPExcel_Coversheet_Headers.php';

	// retrieve the outreach records
	//include 'assets/includes/inc_Coversheet_Report_Query.php';

	// include the report content
	//include 'assets/includes/inc_Coversheet_Report_Content.php';

	// Rename sheet
	$objPHPExcel->getActiveSheet()->setTitle('COVERSHEET');  

	// Create a new worksheet, after the default sheet 
	$objPHPExcel->createSheet();  
	
	// Redirect output to a client's web browser (Excel5) 
	header('Content-Type: application/vnd.ms-excel'); 
	header('Content-Disposition: attachment;filename="name_of_file.xls"'); 
	header('Cache-Control: max-age=0'); 
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5'); 
	$objWriter->save('php://output');

	$file_created = 'Y';
//exit();
?>
<script>
	window.location = "rpt_outreach.php";
</script>