<?php
	include 'assets/includes/inc_Session.php';

	$action_id	 	 = $_REQUEST["Action_ID"];
	$function_type = $_REQUEST["Function_Type"];
	$type					 = '';
	$values 			 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblAction WHERE Action_ID = " . $action_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblAction (
															Action_Value, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Action_Value"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Action_ID) as ID FROM tblAction";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$action_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblAction 
									SET 	 Action_Value = '" . str_replace("'", "''", $_REQUEST["Action_Value"]) . "', 
												 Active				= "  . $_REQUEST["Active"] . "
									WHERE  Action_ID	  = "  . $action_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Action_ID=' . $action_id;
	}
?>

<script>
	alert("Action Value has been <?php echo($type) ?>");
	window.location = "manage_action.php<?php echo $values; ?>";
</script>