<?php
	include 'assets/includes/inc_Session.php';

	date_default_timezone_set('America/Indianapolis');

	$outreach_id = $_REQUEST["Outreach_ID"];
	$function_type = $_REQUEST["Function_Type"];

	if ($function_type == "D") {
		//Delete existing contact_type
		$sqlstmt = "DELETE FROM tblOutreach WHERE Outreach_ID = " . $outreach_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($_REQUEST['Outreach_Date'] != '') {
			$date = strtotime($_REQUEST['Outreach_Date']);
			$_REQUEST['Outreach_Date'] = "'" . date('Y-m-d', $date) . "'";
		}
		else {
			$_REQUEST['Outreach_Date'] = 'NULL';
		}

		if ($function_type == "I") {
			//Insert new contact_type
			$sqlstmt = "INSERT INTO tblOutreach (
															Contact_Type_ID, 
															County_ID, 
															Staff_First_Name, 
															Staff_Last_Name, 
															Outreach_Date, 
															Outreach_Location, 
															Target_Population, 
															Outreach_Contact_Person, 
															Outreach_Contact_Phone, 
															Outreach_Contact_Email, 
															Referral_Number, 
															Enrollment_Number,
															Notes) 
									VALUES (" . $_REQUEST['Contact_Type_ID'] . ", "
														. $_REQUEST['County_ID'] . ", '"
														.	str_replace("'", "''", $_REQUEST["Staff_First_Name"]) . "', '" 
														.	str_replace("'", "''", $_REQUEST["Staff_Last_Name"]) . "', " 
														.	$_REQUEST["Outreach_Date"] . ", '"
														.	str_replace("'", "''", $_REQUEST["Outreach_Location"]) . "', '"
														.	$_REQUEST["Target_Population"] . "', '"
														. str_replace("'", "''", $_REQUEST["Outreach_Contact_Person"]) . "', '" 
														. $_REQUEST["Outreach_Contact_Phone"] . "', '" 
														. $_REQUEST["Outreach_Contact_Email"] . "', '" 
														. $_REQUEST["Referral_Number"] . "', '" 
														. $_REQUEST["Enrollment_Number"] . "', '"
														. str_replace("'", "''", $_REQUEST["Notes"]) . "')";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Outreach_ID) as ID FROM tblOutreach";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$outreach_id = $row['ID'];
				}
			}
		}
		else {
			//Update existing contact_type
			$sqlstmt = "UPDATE tblOutreach 
									SET 	Contact_Type_ID				 	=  " . $_REQUEST['Contact_Type_ID'] . ",
												County_ID				 				=  " . $_REQUEST['County_ID'] . ", 
												Staff_First_Name		 		= '" . str_replace("'", "''", $_REQUEST["Staff_First_Name"]) . "', 
												Staff_Last_Name		 			= '" . str_replace("'", "''", $_REQUEST["Staff_Last_Name"]) . "', 
												Outreach_Date						=  " . $_REQUEST["Outreach_Date"] . ", 
												Outreach_Location	 			= '" . str_replace("'", "''", $_REQUEST["Outreach_Location"]) . "', 
												Target_Population 			= '" . $_REQUEST['Target_Population'] . "', 
												Outreach_Contact_Person = '" . str_replace("'", "''", $_REQUEST["Outreach_Contact_Person"]) . "', 
												Outreach_Contact_Phone 	= '" . $_REQUEST["Outreach_Contact_Phone"] . "', 
												Outreach_Contact_Email 	= '" . $_REQUEST["Outreach_Contact_Email"] . "', 
												Referral_Number					= '" . $_REQUEST["Referral_Number"] . "', 
												Enrollment_Number				= '" . $_REQUEST["Enrollment_Number"] . "', 
												Notes										= '" . str_replace("'", "''", $_REQUEST["Notes"]) . "' 
									WHERE Outreach_ID 						=  " . $outreach_id;

			sqlsrv_query($conn, $sqlstmt);
		}
	}
?>

<script>
	alert("Outreach Information has been saved.");
	window.location = "out_record.php?Outreach_ID=<?php echo $outreach_id; ?>&t=e";
</script>