<?php
	include 'assets/includes/inc_Session.php';

	date_default_timezone_set('America/Indianapolis');

	$resource_id = $_REQUEST["Resource_ID"];
	$function_type = $_REQUEST["Function_Type"];

	if ($function_type == "D") {
		//Delete existing contact_type
		$sqlstmt = "DELETE FROM tblResources WHERE Resource_ID = " . $resource_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			//Insert new contact_type
			$sqlstmt = "INSERT INTO tblResources (
															Resource_Type_ID, 
															State_ID, 
															County_ID, 
															Resource_Name, 
															Contact_Name, 
															Resource_Address, 
															Resource_City, 
															Resource_Zip, 
															Resource_Phone, 
															Resource_Email, 
															Resource_Website, 
															Resource_Comments, 
															Active) 
									VALUES (" . $_REQUEST['Resource_Type_ID'] . ", "
														. $_REQUEST['State_ID'] . ", "
														. $_REQUEST['County_ID'] . ", '"
														.	str_replace("'", "''", $_REQUEST["Resource_Name"]) . "', '" 
														.	str_replace("'", "''", $_REQUEST["Contact_Name"]) . "', '" 
														.	str_replace("'", "''", $_REQUEST["Resource_Address"]) . "', '"
														.	str_replace("'", "''", $_REQUEST["Resource_City"]) . "', '"
														.	$_REQUEST["Resource_Zip"] . "', '"
														. $_REQUEST["Resource_Phone"] . "', '" 
														. $_REQUEST["Resource_Email"] . "', '" 
														. $_REQUEST["Resource_Website"] . "', '" 
														. str_replace("'", "''", $_REQUEST["Resource_Comments"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Resource_ID) as ID FROM tblResources";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$resource_id = $row['ID'];
				}
			}
		}
		else {
			//Update existing contact_type
			$sqlstmt = "UPDATE tblResources 
									SET 	Resource_Type_ID 	=  " . $_REQUEST['Resource_Type_ID'] . ",
												State_ID 				 	=  " . $_REQUEST['State_ID'] . ", 
												County_ID 				=  " . $_REQUEST['County_ID'] . ", 
												Resource_Name 		= '" . str_replace("'", "''", $_REQUEST["Resource_Name"]) . "', 
												Contact_Name 			= '" . str_replace("'", "''", $_REQUEST["Contact_Name"]) . "', 
												Resource_Address	= '" . str_replace("'", "''", $_REQUEST["Resource_Address"]) . "', 
												Resource_City 		= '" . str_replace("'", "''", $_REQUEST["Resource_City"]) . "', 
												Resource_Zip 			= '" . $_REQUEST['Resource_Zip'] . "', 
												Resource_Phone 		= '" . $_REQUEST["Resource_Phone"] . "', 
												Resource_Email 		= '" . $_REQUEST["Resource_Email"] . "', 
												Resource_Website 	= '" . $_REQUEST["Resource_Website"] . "', 
												Resource_Comments = '" . str_replace("'", "''", $_REQUEST["Resource_Comments"]) . "', 
												Active						=  " . $_REQUEST["Active"] . " 
									WHERE Resource_ID 							 				=  " . $resource_id;

			sqlsrv_query($conn, $sqlstmt);
		}
	}
?>

<script>
	alert("Resource Information has been saved.");
	window.location = "res_record.php?Resource_ID=<?php echo $resource_id; ?>&t=e";
</script>