<?php
	include 'assets/includes/inc_Session.php';

	$hear_about_program_id = $_REQUEST["Hear_About_Program_ID"];
	$function_type 				 = $_REQUEST["Function_Type"];
	$type								 	 = '';
	$values				 			 	 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblHearAboutProgram WHERE Hear_About_Program_ID = " . $hear_about_program_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblHearAboutProgram (
															Hear_About_Program_Value, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Hear_About_Program_Value"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Hear_About_Program_ID) as ID FROM tblHearAboutProgram";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$hear_about_program_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblHearAboutProgram 
									SET 	 Hear_About_Program_Value = '" . str_replace("'", "''", $_REQUEST["Hear_About_Program_Value"]) . "', 
												 Active						 		 		= "  . $_REQUEST["Active"] . "
									WHERE  Hear_About_Program_ID	 	= "  . $hear_about_program_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Hear_About_Program_ID=' . $hear_about_program_id;
	}
?>

<script>
	alert("Hear About Program has been <?php echo($type) ?>");
	window.location = "manage_heard.php<?php echo $values; ?>";
</script>