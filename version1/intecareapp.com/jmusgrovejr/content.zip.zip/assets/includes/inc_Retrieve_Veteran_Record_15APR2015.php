<?php
	$veteran_id											 = 0;
	$discharge_status_id						 = 0;
	$service_time_id								 = 0;
	$veteran_income_id							 = 0;
	$hmis_review_id									 = 0;
	$action_id											 = 0;
	$city_id												 = 0;
	$county_id											 = 0;
	$service_branch_id							 = 0;
	$housing_status_id							 = 0;
	$hear_about_program_id					 = 0;
	$case_manager_id								 = 0;
	$veteran_first_name							 = '';
	$veteran_middle_initial					 = '';
	$veteran_last_name							 = '';
	$veteran_address1								 = '';
	$veteran_address2								 = '';
	$veteran_zip_code								 = '';
	$veteran_phone									 = '';
	$other_contact									 = '';
	$other_contact_phone						 = '';
	$city_other											 = '';
	$number_in_house								 = '';
	$initial_contact_date						 = '';
	$initial_call_back_date					 = '';
	$live_answer_yn									 = '';
	$initial_call_back_time					 = '';
	$hudvash_referral								 = '';
	$doc_review											 = '';
	$doc_review_other								 = '';
	$housing_status_notes						 = '';
	$need_assitance_yn							 = '';
	$veteran_service_time						 = '';
	$veteran_monthly_income					 = '';
	$veteran_potentially_eligible_yn = '';
	$referral_cm_date								 = '';
	$referral_cm_time								 = '';
	$initial_appointment_date				 = '';
	$appointment_met_yn							 = '';
	$veteran_enrolled								 = '';
	$category_level									 = '';
	$no_explain											 = '';
	$veteran_active_program					 = '';
	$veteran_exited_program					 = '';
	$exit_date											 = '';
	$insert_by											 = '';
	$insert_date										 = '';
	$edit_by												 = '';
	$edit_date											 = '';

	if ($_REQUEST['t'] == 'e') {
		$sqlstmt = "SELECT	V.Veteran_ID,
												V.Discharge_Status_ID, 
												V.Service_Time_ID, 
												V.Veteran_Income_ID, 
												V.HMIS_Review_ID, 
												V.Action_ID, 
												V.City_ID, 
												V.County_ID, 
												V.Service_Branch_ID, 
												V.Housing_Status_ID, 
												V.Hear_About_Program_ID, 
												V.Case_Manager_ID, 
												V.Veteran_First_Name, 
												V.Veteran_Middle_Initial, 
												V.Veteran_Last_Name,
												V.Veteran_Address1, 
												V.Veteran_Address2,  
												V.Veteran_Zip_Code,  
												V.Veteran_Phone, 
												V.Other_Contact, 
												V.Other_Contact_Phone, 
												V.City_Other, 
												V.Number_In_House, 
												CONVERT(VARCHAR(10),V.Initial_Contact_Date,110) AS Initial_Contact_Date, 
												CONVERT(VARCHAR(10),V.Initial_Call_Back_Date,110) AS Initial_Call_Back_Date, 
												V.Live_Answer_YN, 
												V.Initial_Call_Back_Time, 
												V.HUDVASH_Referral, 
												V.Doc_Review, 
												V.Doc_Review_Other, 
												V.Housing_Status_Notes, 
												V.Need_Assitance_YN,
												V.Veteran_Service_Time, 
												V.Veteran_Monthly_Income, 
												V.Veteran_Potentially_Eligible_YN, 
												CONVERT(VARCHAR(10),V.Referral_CM_Date,110) AS Referral_CM_Date, 
												V.Referral_CM_Time, 
												CONVERT(VARCHAR(10),V.Initial_Appointment_Date,110) AS Initial_Appointment_Date, 
												V.Appointment_Met_YN, 
												V.Veteran_Enrolled, 
												V.Category_Level, 
												V.No_Explain, 
												V.Veteran_Active_Program, 
												V.Veteran_Exited_Program,
												CONVERT(VARCHAR(10),V.Exit_Date,110) AS Exit_Date, 
												V.Insert_By, 
												CONVERT(VARCHAR(10),V.Insert_Date,110) AS Insert_Date, 
												V.Edit_By, 
												CONVERT(VARCHAR(10),V.Edit_Date,110) AS Edit_Date 
								FROM 		tblVeterans V  
								WHERE 	Veteran_ID = " . $_REQUEST['Veteran_ID'];

		if ($result = sqlsrv_query($conn, $sqlstmt)) {
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
				$veteran_id											 = $row['Veteran_ID'];
				$discharge_status_id						 = $row['Discharge_Status_ID'];
				$service_time_id								 = $row['Service_Time_ID'];
				$veteran_income_id							 = $row['Veteran_Income_ID'];
				$hmis_review_id									 = $row['HMIS_Review_ID'];
				$action_id											 = $row['Action_ID'];
				$city_id												 = $row['City_ID'];
				$county_id											 = $row['County_ID'];
				$service_branch_id							 = $row['Service_Branch_ID'];
				$housing_status_id							 = $row['Housing_Status_ID'];
				$hear_about_program_id					 = $row['Hear_About_Program_ID'];
				$case_manager_id								 = $row['Case_Manager_ID'];
				$veteran_first_name							 = $row['Veteran_First_Name'];
				$veteran_middle_initial					 = $row['Veteran_Middle_Initial'];
				$veteran_last_name							 = $row['Veteran_Last_Name'];
				$veteran_address1								 = $row['Veteran_Address1'];
				$veteran_address2								 = $row['Veteran_Address2'];
				$veteran_zip_code								 = $row['Veteran_Zip_Code'];
				$veteran_phone									 = $row['Veteran_Phone'];
				$other_contact									 = $row['Other_Contact'];
				$other_contact_phone						 = $row['Other_Contact_Phone'];
				$city_other											 = $row['City_Other'];
				$number_in_house								 = $row['Number_In_House'];
				$initial_contact_date						 = $row['Initial_Contact_Date'];
				$initial_call_back_date					 = $row['Initial_Call_Back_Date'];
				$live_answer_yn									 = $row['Live_Answer_YN'];
				$initial_call_back_time					 = $row['Initial_Call_Back_Time'];
				$hudvash_referral								 = $row['HUDVASH_Referral'];
				$doc_review											 = $row['Doc_Review'];
				$doc_review_other								 = $row['Doc_Review_Other'];
				$housing_status_notes						 = $row['Housing_Status_Notes'];
				$need_assitance_yn							 = $row['Need_Assitance_YN'];
				$veteran_service_time						 = $row['Veteran_Service_Time'];
				$veteran_monthly_income					 = $row['Veteran_Monthly_Income'];
				$veteran_potentially_eligible_yn = $row['Veteran_Potentially_Eligible_YN'];
				$referral_cm_date								 = $row['Referral_CM_Date'];
				$referral_cm_time								 = $row['Referral_CM_Time'];
				$initial_appointment_date				 = $row['Initial_Appointment_Date'];
				$appointment_met_yn							 = $row['Appointment_Met_YN'];
				$veteran_enrolled								 = $row['Veteran_Enrolled'];
				$category_level									 = $row['Category_Level'];
				$no_explain											 = $row['No_Explain'];
				$veteran_active_program					 = $row['Veteran_Active_Program'];
				$veteran_exited_program					 = $row['Veteran_Exited_Program'];
				$exit_date											 = $row['Exit_Date'];
				$insert_by											 = $row['Insert_By'];
				$insert_date										 = $row['Insert_Date'];
				$edit_by												 = $row['Edit_By'];
				$edit_date											 = $row['Edit_Date'];
			}
		}
	}
?>