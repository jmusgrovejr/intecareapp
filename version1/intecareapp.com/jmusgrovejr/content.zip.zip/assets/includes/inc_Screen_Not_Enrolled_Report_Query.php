<?php
	$db_host = 'localhost';
	$db_user = 'gwc-ssvf';   //recommend using a lower privileged user
	$db_pwd = 'P@ss1234';	//LEFT OUTER JOIN tblDocumentationNotes N ON V.Veteran_ID = N.Veteran_ID
	$database = 'ssvf';
	
	$table = 'ssvf';

	$connectionInfo = array("UID" => $db_user, "PWD" => $db_pwd, "Database"=>$database); 
	$conn = sqlsrv_connect( $db_host, $connectionInfo);

	$sqlstmt_v = "SELECT 
												V.Veteran_ID,
												V.Action_ID,
												V.Veteran_Last_Name,
												V.Veteran_First_Name,
												V.Veteran_Middle_Initial,
												CY.City_Name,
												V.City_Other,
												C.County_Name,
												CONVERT(VARCHAR(10),V.Initial_Contact_Date,110) AS Initial_Contact_Date,
												V.Veteran_Enrolled, 
												V.Housing_Status_Notes
								FROM		tblVeterans V LEFT OUTER JOIN tblCounty C ON V.County_ID = C.County_ID
										LEFT OUTER JOIN tblCity CY ON V.City_ID = CY.City_ID
								WHERE  	V.Action_ID = 2 
								AND     V.Initial_Contact_Date >= '" . $begin_date . "' 
								AND     V.Initial_Contact_Date <  '" . $end_date . "'
								ORDER BY V.Initial_Contact_Date DESC, V.Veteran_Last_Name, V.Veteran_First_Name";
?>