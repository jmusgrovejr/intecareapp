<?php
	$outreach_id						 = 0;
	$veteran_type_id				 = 0;
	$county_id							 = 0;
	$contact_type_id				 = 0;
	$staff_first_name				 = '';
	$staff_last_name				 = '';
	$outreach_date				 	 = '';
	$outreach_location			 = '';
	$target_population			 = '';
	$outreach_contact_person = '';
	$outreach_contact_phone	 = '';
	$outreach_contact_email	 = '';
	$referral_number				 = '';
	$enrollment_number			 = '';
	$notes									 = '';

	if ($_REQUEST['t'] == 'e') {
		$sqlstmt = "SELECT	O.Outreach_ID,
												O.Veteran_ID, 
												O.County_ID, 
												O.Contact_Type_ID, 
												O.Staff_First_Name, 
												O.Staff_Last_Name, 
												CONVERT(VARCHAR(10),O.Outreach_Date,110) AS Outreach_Date, 
												O.Outreach_Location, 
												O.Target_Population, 
												O.Outreach_Contact_Person, 
												O.Outreach_Contact_Phone, 
												O.Outreach_Contact_Email, 
												O.Referral_Number, 
												O.Enrollment_Number, 
												O.Notes
								FROM 		tblOutreach O  
								WHERE 	Outreach_ID = " . $_REQUEST['Outreach_ID'];

		if ($result = sqlsrv_query($conn, $sqlstmt)) {
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
				$outreach_id						 = $row['Outreach_ID'];
				$veteran_type_id				 = $row['Veteran_ID'];
				$county_id							 = $row['County_ID'];
				$contact_type_id				 = $row['Contact_Type_ID'];
				$county_id							 = $row['County_ID'];
				$staff_first_name				 = $row['Staff_First_Name'];
				$staff_last_name				 = $row['Staff_Last_Name'];
				$outreach_date				 	 = $row['Outreach_Date'];
				$outreach_location			 = $row['Outreach_Location'];
				$target_population			 = $row['Target_Population'];
				$outreach_contact_person = $row['Outreach_Contact_Person'];
				$outreach_contact_phone	 = $row['Outreach_Contact_Phone'];
				$outreach_contact_email	 = $row['Outreach_Contact_Email'];
				$referral_number				 = $row['Referral_Number'];
				$enrollment_number			 = $row['Enrollment_Number'];
				$notes									 = $row['Notes'];
			}
		}
	}
?>