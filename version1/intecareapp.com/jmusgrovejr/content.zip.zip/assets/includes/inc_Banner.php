<div id="top_banner" class="title">
	<div style="float:left"><img src="assets/images/logo.png" width="257" height="56" border="0" alt="American Sports of Sports Medicine" /></div>
	<div style="float:left">&nbsp;&nbsp;&nbsp;ACSM - Exercise is Medicine</div>
</div>

<div id="welcome" class="back">Welcome back, <?php echo($_SESSION['Admin_First_Name'] . ' ' . $_SESSION['Admin_Last_Name']) ?></div>