<?php
	$j = 5;
	if ($result = sqlsrv_query($conn, $sqlstmt)) {
		while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
			$objPHPExcel->getActiveSheet()->setCellValue('A' . $j, $row["Veteran_Last_Name"]);
			$objPHPExcel->getActiveSheet()->setCellValue('B' . $j, $row["Veteran_First_Name"]);
			$objPHPExcel->getActiveSheet()->setCellValue('C' . $j, $row["Veteran_Address1"]);
			$objPHPExcel->getActiveSheet()->setCellValue('D' . $j, $row["Veteran_Address2"]);
			$objPHPExcel->getActiveSheet()->setCellValue('E' . $j, $row["Veteran_Zip_Code"]);
			$objPHPExcel->getActiveSheet()->setCellValue('F' . $j, $row["Veteran_Phone"]);
			$objPHPExcel->getActiveSheet()->setCellValue('G' . $j, $row["Housing_Status_Value"]);
			$objPHPExcel->getActiveSheet()->setCellValue('H' . $j, $row["Referral_CM_Date"]);
			$objPHPExcel->getActiveSheet()->setCellValue('I' . $j, $row["Initial_Appointment_Date"]);
			$objPHPExcel->getActiveSheet()->setCellValue('J' . $j, $row["Appointment_Met_YN"]);
			$objPHPExcel->getActiveSheet()->setCellValue('K' . $j, $row["Veteran_Enrolled"]);
			$objPHPExcel->getActiveSheet()->setCellValue('L' . $j, $row["Category_Level"]);
			$objPHPExcel->getActiveSheet()->setCellValue('M' . $j, $row["Case_Manager_Name"]);
			$j++;
		}
	}
?>