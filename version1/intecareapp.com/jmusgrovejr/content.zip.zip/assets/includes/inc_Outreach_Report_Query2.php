<?php
	$db_host = 'localhost';
	$db_user = 'gwc-ssvf';   //recommend using a lower privileged user
	$db_pwd = 'P@ss1234';
	$database = 'ssvf';
	
	$table = 'ssvf';

	$connectionInfo = array("UID" => $db_user, "PWD" => $db_pwd, "Database"=>$database); 
	$conn = sqlsrv_connect( $db_host, $connectionInfo);

	$serach_begin_date_stmt = "";
	$serach_end_date_stmt   = "";
	$serach_county_id_stmt  = "";

	$search_begin_date = date('Y-m-d', strtotime($begin_date));
	$search_end_date = date('Y-m-d', strtotime($end_date));
	

	if ($_REQUEST['Search_Begin_Date'] != '') $serach_begin_date_stmt = " AND O.Outreach_Date >= '" . $search_begin_date . "'";
	if ($_REQUEST['Search_End_Date'] != '') $serach_end_date_stmt = " AND O.Outreach_Date <= '" . $search_end_date . "'";
	if ($_REQUEST['Search_County_ID'] != '') $search_county_id_stmt = " AND O.County_ID = " . $_REQUEST['Search_County_ID'];
	
	$sqlstmt = "SELECT 	O.Staff_First_Name,
											O.Staff_Last_Name,
											O.Outreach_Date,
											O.Outreach_Location,
											O.Target_Population,
											O.Outreach_Contact_Person,
											O.Outreach_Contact_Phone,
											O.Outreach_Contact_Email,
											O.Referral_Number, 
											O.Enrollment_Number, 
											O.Notes,
											T.Contact_Type_Name

							FROM		tblOutreach O LEFT OUTER JOIN tblContactType T ON O.Contact_Type_ID = T.Contact_Type_ID
LEFT OUTER JOIN tblVeterans V ON O.Veteran_ID = V.Veteran_ID
LEFT OUTER JOIN tblCaseManagers C ON V.Case_Manager_ID = C.Case_Manager_ID								
LEFT OUTER JOIN tblCounty Cy ON O.County_ID = Cy.County_ID
							WHERE  	1=1 " .
							$serach_begin_date_stmt . 
							$serach_end_date_stmt . 
							$search_county_id_stmt . "
							ORDER BY Cy.County_Name, O.Outreach_Date DESC";
?>