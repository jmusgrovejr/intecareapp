<?php
	$hear_about_program_id	 	= 0;
	$hear_about_program_value = '';
	$active						 				= '';

	$selected_hear_about_program_id = $_REQUEST['Hear_About_Program_ID'];

	if ($selected_hear_about_program_id != "") {
		$sqlstmt = "SELECT	Hear_About_Program_ID, 
												Hear_About_Program_Value, 
												Active
							  FROM 		tblHearAboutProgram 
								WHERE 	Hear_About_Program_ID = " . $selected_hear_about_program_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$hear_about_program_id 	 	= $row['Hear_About_Program_ID'];
				$hear_about_program_value = $row['Hear_About_Program_Value'];
				$active						 				= $row['Active'];
			}
		}
	}
?>