<?php
	$discharge_status_id	 = 0;
	$discharge_status_name = '';
	$active						 = '';

	$selected_discharge_status_id = $_REQUEST['Discharge_Status_ID'];

	if ($selected_discharge_status_id != "") {
		$sqlstmt = "SELECT	Discharge_Status_ID, 
												Discharge_Status_Name, 
												Active
							  FROM 		tblDischargeStatus 
								WHERE 	Discharge_Status_ID = " . $selected_discharge_status_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$discharge_status_id 	 = $row['Discharge_Status_ID'];
				$discharge_status_name = $row['Discharge_Status_Name'];
				$active						 		 = $row['Active'];
			}
		}
	}
?>