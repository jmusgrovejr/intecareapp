<?php
	$sqlstmt = "SELECT	R.Resource_Type_ID,
											R.Resource_Name
							FROM 		tblResourceTypes R  
							WHERE 	R.Active = 1 
							ORDER BY R.Resource_Name";

	if (isset($veteran_id)) {
		$sqlstmt_r = "SELECT	R.Veteran_ID,
													R.Resource_Type_ID
									FROM 		tblVeteransResourceTypesAssoc R  
									WHERE 	R.Veteran_ID = " . $veteran_id; 
	}
?>