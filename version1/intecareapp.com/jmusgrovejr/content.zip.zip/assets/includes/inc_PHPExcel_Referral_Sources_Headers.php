<?php
	$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
	$objPHPExcel->getDefaultStyle()->getFont()->setSize(11); 

	$objPHPExcel->getActiveSheet()->getStyle('A1:B1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('8064A2');
	$objPHPExcel->getActiveSheet()->getStyle('A1:B1')->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_WHITE);
	$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_WHITE);

	$objPHPExcel->getActiveSheet()->setCellValue('A1', 'REFERRAL SOURCES');  
	$objPHPExcel->getActiveSheet()->setCellValue('B1', '# ENROLLED');  

	$objPHPExcel->getDefaultStyle()->getFont()->setSize(10); 
?>