<?php
	$search_county_id_stmt				= '';
	$search_resource_name_stmt 		= '';
	$search_resource_city_stmt 		= '';
	$search_zip_code_stmt 				= '';
	$search_resource_type_id_stmt	= '';
	
	if ($_REQUEST['Search_County_ID'] != '') $search_county_id_stmt = " AND R.County_ID = " . $_REQUEST['Search_County_ID'];
	if ($_REQUEST['Search_Resource_Name'] != '') $search_resource_name_stmt = " AND R.Resource_Name LIKE '%" . $_REQUEST['Search_Resource_Name'] . "%'";
	if ($_REQUEST['Search_Resource_City'] != '') $search_resource_city_stmt = " AND R.Resource_City LIKE '%" . $_REQUEST['Search_Resource_City'] . "%'";
	if ($_REQUEST['Search_Zip_Code'] != '') $search_zip_code_stmt = " AND R.Resource_Zip LIKE '%" . $_REQUEST['Search_Zip_Code'] . "%'";
	if ($_REQUEST['Search_Resource_Type_ID'] != '') $search_resource_type_id_stmt = " AND R.Resource_Type_ID = " . $_REQUEST['Search_Resource_Type_ID'];

	$sqlstmt = "SELECT	R.Resource_ID,
											RT.Resource_Name AS Resource_Type_Name, 
											R.Resource_Name, 
											R.Resource_City, 
											R.Resource_Address, 
											CT.County_Name 
							FROM 		tblResources R LEFT OUTER JOIN tblResourceTypes RT ON R.Resource_Type_ID = RT.Resource_Type_ID
																		 LEFT OUTER JOIN tblCounty CT ON R.County_ID = CT.County_ID 
							WHERE 	1=1 " .
							$search_county_id_stmt . 
							$search_resource_name_stmt .
							$search_resource_city_stmt .
							$search_zip_code_stmt .
							$search_resource_type_id_stmt . "
							ORDER BY R.Resource_Name";

	$params = array();
	$options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
	$stmt = sqlsrv_query( $conn, $sqlstmt , $params, $options );
	$row_count = sqlsrv_num_rows( $stmt );
?>