<?php
	$sqlstmt = "SELECT	S.Service_Time_ID,
											S.Service_Time_Value
							FROM 		tblServiceTime S  
							WHERE 	S.Active = 1 
							ORDER BY S.Service_Time_ID";
?>