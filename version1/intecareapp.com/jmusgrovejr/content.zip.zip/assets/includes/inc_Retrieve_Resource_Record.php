<?php
	$resource_id			 = 0;
	$resource_type_id	 = 0;
	$state_id					 = 0;
	$county_id				 = 0;
	$resource_name		 = '';
	$contact_name			 = '';
	$resource_address	 = '';
	$resource_city		 = '';
	$resource_zip			 = '';
	$resource_phone		 = '';
	$resource_email		 = '';
	$resource_website	 = '';
	$resource_comments = '';
	$active						 = '';

	if ($_REQUEST['t'] == 'e') {
		$sqlstmt = "SELECT	R.Resource_ID,
												R.Resource_Type_ID, 
												R.State_ID, 
												R.County_ID, 
												R.Resource_Name, 
												R.Contact_Name, 
												R.Resource_Address, 
												R.Resource_City, 
												R.Resource_Zip, 
												R.Resource_Phone, 
												R.Resource_Email, 
												R.Resource_Website, 
												R.Resource_Comments, 
												R.Active
								FROM 		tblResources R  
								WHERE 	Resource_ID = " . $_REQUEST['Resource_ID'];

		if ($result = sqlsrv_query($conn, $sqlstmt)) {
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
				$resource_id			 = $row['Resource_ID'];
				$resource_type_id	 = $row['Resource_Type_ID'];
				$state_id					 = $row['State_ID'];
				$county_id				 = $row['County_ID'];
				$resource_name		 = $row['Resource_Name'];
				$contact_name			 = $row['Contact_Name'];
				$resource_address	 = $row['Resource_Address'];
				$resource_city		 = $row['Resource_City'];
				$resource_zip			 = $row['Resource_Zip'];
				$resource_phone		 = $row['Resource_Phone'];
				$resource_email		 = $row['Resource_Email'];
				$resource_website	 = $row['Resource_Website'];
				$resource_comments = $row['Resource_Comments'];
				$active						 = $row['Active'];
			}
		}
	}
?>