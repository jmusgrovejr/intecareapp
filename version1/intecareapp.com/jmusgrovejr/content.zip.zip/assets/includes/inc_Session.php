<?php
	session_start();

	if(isset($_SESSION['First_Name'])) {
		// Make a connection to the database
		include 'assets/includes/inc_DatabaseConnection.php';
	}
	else {
		header("Location: index.php");
  	exit();
	}	
?>