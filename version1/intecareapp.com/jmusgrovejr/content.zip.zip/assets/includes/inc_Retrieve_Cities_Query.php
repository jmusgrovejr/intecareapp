<?php
	$city_id	 = 0;
	$county_id = 0;
	$city_name = '';
	$active		 = '';

	$selected_city_id = $_REQUEST['City_ID'];

	if ($selected_city_id != "") {
		$sqlstmt = "SELECT	City_ID, 
												County_ID, 
												City_Name, 
												Active
							  FROM 		tblCity 
								WHERE 	City_ID = " . $selected_city_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$city_id 	 = $row['City_ID'];
				$county_id = $row['County_ID'];
				$city_name = $row['City_Name'];
				$active		 = $row['Active'];
			}
		}
	}
?>