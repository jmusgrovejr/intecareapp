<?php
	$j = 2;

	$fill_color = 'DAEEF3';	

	if ($result = sqlsrv_query($conn, $sqlstmt)) {
		while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
			$objPHPExcel->getActiveSheet()->getStyle('A' . $j . ':D' . $j)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB($fill_color);
			$objPHPExcel->getActiveSheet()->setCellValue('A' . $j, $row["Veteran_First_Name"] . ' ' . $row["Veteran_Last_Name"]);
			$objPHPExcel->getActiveSheet()->setCellValue('B' . $j, $row["Referral_CM_Date"]);
			$objPHPExcel->getActiveSheet()->setCellValue('C' . $j, $row["No_Explain"]);
	
			include 'assets/includes/inc_Retrieve_Resouces_Provided_Query.php';
	
			$objPHPExcel->getActiveSheet()->setCellValue('D' . $j, $resource_name);
	
			if ($fill_color == 'DAEEF3') $fill_color = 'FFFFFF';
			else $fill_color = 'DAEEF3';
	
			$j++;
		}
	}
?>