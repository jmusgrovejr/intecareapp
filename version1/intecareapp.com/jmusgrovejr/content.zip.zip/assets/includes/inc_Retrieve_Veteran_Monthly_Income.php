<?php
	$sqlstmt = "SELECT	V.Veteran_Income_ID,
											V.Veteran_Income_Amount
							FROM 		tblVeteranIncome V 
							WHERE 	V.Active = 1 
							ORDER BY V.Veteran_Income_ID";
?>