<?php
	$main_content_id	 = 0;
	$main_content = 0;
	$last_updated_by = '';
	$last_updated_date		 = '';

	$sqlstmt = "SELECT	M.Main_Content_ID, 
											M.Main_Content, 
											M.Last_Updated_By, 
											CONVERT(VARCHAR(10),Last_Updated_Date,110) AS Last_Updated_Date
							FROM 		tblMainContent M
							WHERE 	M.Main_Content_ID = 1";

	if ($result = sqlsrv_query($conn, $sqlstmt)) {
		while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
			$main_content_id 	 = $row['Main_Content_ID'];
			$main_content			 = $row['Main_Content'];
			$last_updated_by	 = $row['Last_Updated_By'];
			$last_updated_date = $row['Last_Updated_Date'];
		}
	}
?>