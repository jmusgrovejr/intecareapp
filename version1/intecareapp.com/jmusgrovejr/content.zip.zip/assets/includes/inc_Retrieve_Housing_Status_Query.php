<?php
	$housing_status_id	 	= 0;
	$housing_status_value = '';
	$active						 		= '';

	$selected_housing_status_id = $_REQUEST['Housing_Status_ID'];

	if ($selected_housing_status_id != "") {
		$sqlstmt = "SELECT	Housing_Status_ID, 
												Housing_Status_Value, 
												Active
							  FROM 		tblHousingStatus 
								WHERE 	Housing_Status_ID = " . $selected_housing_status_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$housing_status_id 	 	= $row['Housing_Status_ID'];
				$housing_status_value = $row['Housing_Status_Value'];
				$active								= $row['Active'];
			}
		}
	}
?>