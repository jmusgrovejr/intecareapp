<?php
	$sqlstmt = "SELECT	S.Housing_Status_ID,
											S.Housing_Status_Value
							FROM 		tblHousingStatus S  
							WHERE 	S.Active = 1 
							ORDER BY S.Housing_Status_Value";
?>