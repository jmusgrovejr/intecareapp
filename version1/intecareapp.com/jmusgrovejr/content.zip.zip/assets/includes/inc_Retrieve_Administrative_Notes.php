<?php
	$sqlstmt = "SELECT	N.Administrative_Note_ID,
											N.Veteran_ID,
											N.User_ID, 
											U.First_Name,
											U.Last_Name,
											N.Administrative_Note_Desc,
											CONVERT(VARCHAR(10),N.Note_Date_Time,110) AS Note_Date_Time
							FROM 		tblAdministrativeNotes N, tblUsers U 
							WHERE 	N.User_ID = U.User_ID 
							AND			N.Veteran_ID = " . $veteran_id . "
							ORDER BY N.Note_Date_Time DESC";
?>