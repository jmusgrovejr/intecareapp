<?php
	$db_host = 'localhost';
	$db_user = 'gwc-ssvf';   //recommend using a lower privileged user
	$db_pwd = 'P@ss1234';
	$database = 'ssvf';
	
	$table = 'ssvf';

	$connectionInfo = array("UID" => $db_user, "PWD" => $db_pwd, "Database"=>$database); 
	$conn = sqlsrv_connect( $db_host, $connectionInfo);

	$serach_begin_date_stmt = "";
	$serach_end_date_stmt 	= "";

	if ($_REQUEST['Search_Reporting_Year'] != 'All')
	    $serach_begin_date_stmt = " AND V.Referral_CM_Date >= '" . $begin_date->format('Y-m-d') . "'";
	
	if ($_REQUEST['Search_Reporting_Month'] != 'All')
	    $serach_end_date_stmt = " AND V.Referral_CM_Date <= '" . $end_date->format('Y-m-d') . "'"; 

	$sqlstmt_v = "SELECT 	V.Veteran_ID, 
												CONVERT(VARCHAR(10),V.Referral_CM_Date,110) AS Referral_CM_Date,
												V.Veteran_Last_Name,
												V.Veteran_First_Name,
												V.Veteran_Phone,
												C.County_Name,
												Y.City_Name,
												V.City_Other,
												H.HMIS_Review_Value,
												V.Veteran_Enrolled, 
												V.Other_Contact 
								FROM		tblVeterans V LEFT OUTER JOIN tblCity Y ON V.City_ID = Y.City_ID
																			LEFT OUTER JOIN tblCounty C ON V.County_ID = C.County_ID
																			LEFT OUTER JOIN tblHMISReview H ON V.HMIS_Review_ID = H.HMIS_Review_ID
								WHERE  	1=1" .
                                      $serach_begin_date_stmt .
							$serach_end_date_stmt . "
								ORDER BY V.Referral_CM_Date DESC, V.Veteran_Last_Name, V.Veteran_First_Name";
?>