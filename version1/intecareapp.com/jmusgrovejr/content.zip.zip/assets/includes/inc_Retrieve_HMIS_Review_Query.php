<?php
	$service_time_id	 	 = 0;
	$service_time_value = '';
	$active						 = '';

	$selected_service_time_id = $_REQUEST['HMIS_Review_ID'];

	if ($selected_service_time_id != "") {
		$sqlstmt = "SELECT	HMIS_Review_ID, 
												HMIS_Review_Value, 
												Active
							  FROM 		tblHMISReview 
								WHERE 	HMIS_Review_ID = " . $selected_service_time_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
			$hmis_review_id 	 = $row['HMIS_Review_ID'];
			$hmis_review_value = $row['HMIS_Review_Value'];
			$active						 = $row['Active'];
			}
		}
	}
?>