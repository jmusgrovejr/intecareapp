<?php
	$user_type_id		= 0;
	$user_type_desc = '';
	$active					= '';

	$selected_user_type_id = $_REQUEST['User_Type_ID'];

	if ($selected_user_type_id != "") {
		$sqlstmt = "SELECT	User_Type_ID, 
												User_Type_Desc, 
												Active
							  FROM 		tblUserTypes 
								WHERE 	User_Type_ID = " . $selected_user_type_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$user_type_id 	= $row['User_Type_ID'];
				$user_type_desc = $row['User_Type_Desc'];
				$active					= $row['Active'];
			}
		}
	}
?>