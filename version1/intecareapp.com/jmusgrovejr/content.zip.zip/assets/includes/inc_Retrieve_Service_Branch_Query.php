<?php
	$service_branch_id	 	= 0;
	$service_branch_value = '';
	$active						 	= '';

	$selected_service_branch_id = $_REQUEST['Service_Branch_ID'];

	if ($selected_service_branch_id != "") {
		$sqlstmt = "SELECT	Service_Branch_ID, 
												Service_Branch_Value, 
												Active
							  FROM 		tblServiceBranch 
								WHERE 	Service_Branch_ID = " . $selected_service_branch_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$service_branch_id 	 	= $row['Service_Branch_ID'];
				$service_branch_value = $row['Service_Branch_Value'];
				$active								= $row['Active'];
			}
		}
	}
?>