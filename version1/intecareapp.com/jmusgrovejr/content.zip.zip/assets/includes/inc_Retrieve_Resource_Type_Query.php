<?php
	$resource_type_id	= 0;
	$resource_name		= '';
	$active						= '';

	$selected_resource_type_id = $_REQUEST['Resource_Type_ID'];

	if ($selected_resource_type_id != "") {
		$sqlstmt = "SELECT	Resource_Type_ID, 
												Resource_Name, 
												Active
							  FROM 		tblResourceTypes 
								WHERE 	Resource_Type_ID = " . $selected_resource_type_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
			$resource_type_id = $row['Resource_Type_ID'];
			$resource_name 		= $row['Resource_Name'];
			$active						= $row['Active'];
			}
		}
	}
?>