<?php

	$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
	$objPHPExcel->getDefaultStyle()->getFont()->setSize(11); 

	$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A1:H1')->getFont()->setBold(true);
 
	$objPHPExcel->getActiveSheet()->getStyle('A2:H2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A2:H2')->getFont()->setBold(true);

	$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A3:H3')->getFont()->setBold(true);

	$objPHPExcel->getActiveSheet()->getStyle('A4:H4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A4:H4')->getFont()->setBold(true);
 
	$objPHPExcel->getActiveSheet()->setCellValue('A1', 'Screen But Not Enrolled Report');
	$objPHPExcel->getActiveSheet()->setCellValue('D2', date('m/d/Y')); 
	$objPHPExcel->getActiveSheet()->setCellValue('A3', ' '); 

	$objPHPExcel->getActiveSheet()->mergeCells('A1:H1');#1F497D
	$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

	$objPHPExcel->getActiveSheet()->mergeCells('A2:H2');
	$objPHPExcel->getActiveSheet()->getStyle('A2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

	$objPHPExcel->getActiveSheet()->mergeCells('A3:H3');
	$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
 
	$objPHPExcel->getActiveSheet()->setCellValue('A4', 'LAST NAME');  
	$objPHPExcel->getActiveSheet()->setCellValue('B4', 'FIRST NAME');  
	$objPHPExcel->getActiveSheet()->setCellValue('C4', 'MIDDLE INITIAL');  
	$objPHPExcel->getActiveSheet()->setCellValue('D4', 'City');  
	$objPHPExcel->getActiveSheet()->setCellValue('E4', 'COUNTY');  
	$objPHPExcel->getActiveSheet()->setCellValue('F4', 'INITIAL CONTACT DATE');  
	$objPHPExcel->getActiveSheet()->setCellValue('G4', 'HOUSING STATUS NOTES'); 
	$objPHPExcel->getActiveSheet()->setCellValue('H4', 'NOTES'); 

	$objPHPExcel->getDefaultStyle()->getFont()->setSize(10); 
?>