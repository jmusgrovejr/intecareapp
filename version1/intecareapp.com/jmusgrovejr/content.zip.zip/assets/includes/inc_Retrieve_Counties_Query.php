<?php
	$county_id	 = 0;
	$county_name = '';
	$county_code = '';
	$active			 = '';

	$selected_county_id = $_REQUEST['County_ID'];

	if ($selected_county_id != "") {
		$sqlstmt = "SELECT	County_ID, 
												County_Name, 
												County_Code, 
												Active
							  FROM 		tblCounty 
								WHERE 	County_ID = " . $selected_county_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$county_id	 = $row['County_ID'];
				$county_name = $row['County_Name'];
				$county_code = $row['County_Code'];
				$active			 = $row['Active'];
			}
		}
	}
?>