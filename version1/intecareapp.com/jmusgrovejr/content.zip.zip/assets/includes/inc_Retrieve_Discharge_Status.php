<?php
	$sqlstmt = "SELECT	D.Discharge_Status_ID,
											D.Discharge_Status_Name
							FROM 		tblDischargeStatus D  
							WHERE 	D.Active = 1 
							ORDER BY D.Discharge_Status_Name";
?>