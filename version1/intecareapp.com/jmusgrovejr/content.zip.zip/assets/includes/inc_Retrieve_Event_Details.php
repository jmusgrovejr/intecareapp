<?php
	$sqlstmt = "SELECT	E.Event_ID, 
											E.Event_Title, 
											CONVERT(VARCHAR(10), E.Event_Begin_Date, 110) AS Event_Begin_Date, 
											E.Event_Begin_Time, 
											CONVERT(VARCHAR(10), E.Event_End_Date, 110) AS Event_End_Date, 
											E.Event_End_Time, 
											E.Event_Location, 
											E.Event_Description
							FROM 		tblEventCalendar E
							WHERE 	E.Event_ID = " . $_REQUEST['EID'];

	if ($result = sqlsrv_query($conn, $sqlstmt)) {
		while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
			$event_id				 	 = $row['Event_ID'];
			$event_title			 = $row['Event_Title'];
			$event_begin_date	 = $row['Event_Begin_Date'];
			$event_begin_time	 = $row['Event_Begin_Time'];
			$event_end_date		 = $row['Event_End_Date'];
			$event_end_time		 = $row['Event_End_Time'];
			$event_location		 = $row['Event_Location'];
			$event_description = $row['Event_Description'];
		}
	}
?>