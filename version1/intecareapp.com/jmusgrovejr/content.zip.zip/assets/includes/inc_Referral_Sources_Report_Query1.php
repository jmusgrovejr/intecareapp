<?php
	$db_host = 'localhost';
	$db_user = 'gwc-ssvf';   //recommend using a lower privileged user
	$db_pwd = 'P@ss1234';
	$database = 'ssvf';
	
	$table = 'ssvf';

	$connectionInfo = array("UID" => $db_user, "PWD" => $db_pwd, "Database"=>$database); 
	$conn = sqlsrv_connect( $db_host, $connectionInfo);

	$serach_begin_date_stmt = "";
	$serach_end_date_stmt 	= "";
	$serach_county_id_stmt 	= "";

	$search_begin_date = date('Y-m-d', strtotime($begin_date));
	$search_end_date = date('Y-m-d', strtotime($end_date));
	
	if ($_REQUEST['Search_Begin_Date'] != '') $serach_begin_date_stmt = " AND V.Referral_CM_Date >= '" . $search_begin_date . "'";
	if ($_REQUEST['Search_End_Date'] != '') $serach_end_date_stmt = " AND V.Referral_CM_Date <= '" . $search_end_date . "'";
	if ($_REQUEST['Search_County_ID'] != '') $search_county_id_stmt = " AND V.County_ID = " . $_REQUEST['Search_County_ID'];
	
	$sqlstmt = "SELECT 	COUNT(V.Hear_About_Program_ID) AS Referral_Count,
											H.Hear_About_Program_Value
							FROM		tblVeterans V, tblHearAboutProgram H
							WHERE  	V.Hear_About_Program_ID = H.Hear_About_Program_ID" .
							$serach_begin_date_stmt .
							$serach_end_date_stmt .
							$search_county_id_stmt . "
							GROUP BY V.Hear_About_Program_ID
							ORDER BY H.Hear_About_Program_Value";
?>