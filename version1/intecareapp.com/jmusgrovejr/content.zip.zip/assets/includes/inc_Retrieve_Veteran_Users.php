<?php
	$sqlstmt = "SELECT	U.User_ID,
											U.First_Name,
	U.Last_Name
							FROM 		tblUsers U  
							WHERE 	U.Active = 1 
							ORDER BY U.Last_Name";
?>