<?php
	$veteran_income_id	 	 = 0;
	$veteran_income_amount = '';
	$active						 		 = '';

	$selected_veteran_income_id = $_REQUEST['Veteran_Income_ID'];

	if ($selected_veteran_income_id != "") {
		$sqlstmt = "SELECT	Veteran_Income_ID, 
												Veteran_Income_Amount, 
												Active
							  FROM 		tblVeteranIncome 
								WHERE 	Veteran_Income_ID = " . $selected_veteran_income_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$veteran_income_id 	 	 = $row['Veteran_Income_ID'];
				$veteran_income_amount = $row['Veteran_Income_Amount'];
				$active								 = $row['Active'];
			}
		}
	}
?>