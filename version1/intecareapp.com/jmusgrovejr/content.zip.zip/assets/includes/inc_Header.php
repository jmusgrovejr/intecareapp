<div><img src="assets/images/ssvf_header.fw.png" width="1000" height="483" border="0" /></div>

<div id="main_welcome" class="welcome_title">
  WELCOME
  <div style="line-height:15px">&nbsp;</div>
  <div class="welcome_name"><?php echo $_SESSION['First_Name'] . ' ' . $_SESSION['Last_Name']; ?></div>
</div>
