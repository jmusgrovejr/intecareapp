<?php
	$service_time_id	 	= 0;
	$service_time_value = '';
	$active						 	= '';

	$selected_service_time_id = $_REQUEST['Service_Time_ID'];

	if ($selected_service_time_id != "") {
		$sqlstmt = "SELECT	Service_Time_ID, 
												Service_Time_Value, 
												Active
							  FROM 		tblServiceTime 
								WHERE 	Service_Time_ID = " . $selected_service_time_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$service_time_id 	 	= $row['Service_Time_ID'];
				$service_time_value = $row['Service_Time_Value'];
				$active							= $row['Active'];
			}
		}
	}
?>