<?php
	$action_id		= 0;
	$action_value = '';
	$active				= '';

	$selected_action_id = $_REQUEST['Action_ID'];

	if ($selected_action_id != "") {
		$sqlstmt = "SELECT	Action_ID, 
												Action_Value, 
												Active
							  FROM 		tblAction 
								WHERE 	Action_ID = " . $selected_action_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) {
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
				$action_id 		= $row['Action_ID'];
				$action_value = $row['Action_Value'];
				$active				= $row['Active'];
			}
		}
	}
?>