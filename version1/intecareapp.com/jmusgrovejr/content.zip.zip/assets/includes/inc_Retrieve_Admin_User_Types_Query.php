<?php
	$user_type_id 	= 0;
	$user_type_desc = "";
	$user_type_code = "";
	$active 			  = "";
	
	$selected_user_type_id = $_REQUEST['User_Type_ID'];

	if ($selected_user_type_id != "") {
		$sqlstmt = "SELECT	User_Type_ID, 
												User_Type_Desc, 
												User_Type_Code, 
												Active
								FROM 		tblUserTypes 
								WHERE 	User_Type_ID = " . $selected_user_type_id;
		mysqli_select_db($link, $database) or die( "Unable to select database");

		if ($result = mysqli_query($link, $sqlstmt)) {
			while ($i = mysqli_fetch_array($result)) {
				$user_type_id	  = $i['User_Type_ID'];
				$user_type_desc = $i['User_Type_Desc'];
				$user_type_code = $i['User_Type_Code'];
				$active				  = $i['Active'];
			}
		}
	}
?>