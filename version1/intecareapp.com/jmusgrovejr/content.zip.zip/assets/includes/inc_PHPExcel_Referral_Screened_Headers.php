<?php
	$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
	$objPHPExcel->getDefaultStyle()->getFont()->setSize(11); 

	$objPHPExcel->getActiveSheet()->getStyle('A1:D1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('4BACC6');
	$objPHPExcel->getActiveSheet()->getStyle('A1:D1')->getFont()->setBold(true);
	$objPHPExcel->getActiveSheet()->getStyle('A1')->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_WHITE);
	$objPHPExcel->getActiveSheet()->getStyle('B1')->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_WHITE);
	$objPHPExcel->getActiveSheet()->getStyle('C1')->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_WHITE);
	$objPHPExcel->getActiveSheet()->getStyle('D1')->getFont()->getColor()->setARGB(PHPExcel_Style_Color::COLOR_WHITE);

	$objPHPExcel->getActiveSheet()->setCellValue('A1', 'REFERRAL / SCREENED - NOT ENROLLED');  
	$objPHPExcel->getActiveSheet()->setCellValue('B1', 'DATE OF REFERRAL');  
	$objPHPExcel->getActiveSheet()->setCellValue('C1', 'REASON');  
	$objPHPExcel->getActiveSheet()->setCellValue('D1', 'RESOURCES PROVIDED');  

	$objPHPExcel->getDefaultStyle()->getFont()->setSize(10); 
?>