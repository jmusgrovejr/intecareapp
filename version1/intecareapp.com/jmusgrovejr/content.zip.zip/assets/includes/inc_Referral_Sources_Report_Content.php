<?php
	$j = 2;

	$fill_color = 'E4DFEC';	

	if ($result = sqlsrv_query($conn, $sqlstmt)) {
		while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
			$objPHPExcel->getActiveSheet()->getStyle('A' . $j . ':B' . $j)->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB($fill_color);
			$objPHPExcel->getActiveSheet()->setCellValue('A' . $j, $row["Hear_About_Program_Value"]);
			$objPHPExcel->getActiveSheet()->setCellValue('B' . $j, $row["Referral_Count"]);
	
			if ($fill_color == 'E4DFEC') $fill_color = 'FFFFFF';
			else $fill_color = 'E4DFEC';
	
			$j++;
		}
	}
?>