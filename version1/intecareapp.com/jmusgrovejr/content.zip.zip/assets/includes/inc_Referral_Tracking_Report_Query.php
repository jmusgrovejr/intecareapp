<?php
	$db_host = 'localhost';
	$db_user = 'gwc-ssvf';   //recommend using a lower privileged user
	$db_pwd = 'P@ss1234';
	$database = 'ssvf';
	
	$table = 'ssvf';

	$connectionInfo = array("UID" => $db_user, "PWD" => $db_pwd, "Database"=>$database); 
	$conn = sqlsrv_connect( $db_host, $connectionInfo);

	$sqlstmt_v = "SELECT 	V.Veteran_ID, 
												CONVERT(VARCHAR(10),V.Referral_CM_Date,110) AS Referral_CM_Date,
												V.Veteran_Last_Name,
												V.Veteran_First_Name,
												V.Veteran_Phone,
												C.County_Name,
												Y.City_Name,
												V.City_Other,
												H.HMIS_Review_Value,
												V.Veteran_Enrolled, 
												V.Other_Contact 
								FROM		tblVeterans V LEFT OUTER JOIN tblCity Y ON V.City_ID = Y.City_ID
																			LEFT OUTER JOIN tblCounty C ON V.County_ID = C.County_ID
																			LEFT OUTER JOIN tblHMISReview H ON V.HMIS_Review_ID = H.HMIS_Review_ID
								WHERE  	1=1
								AND V.Referral_CM_Date >= '" . $begin_date->format('Y-m-d') . "' 
								AND V.Referral_CM_Date < '" . $end_date->format('Y-m-d') . "' 
								ORDER BY V.Referral_CM_Date DESC, V.Veteran_Last_Name, V.Veteran_First_Name";
?>