<?php
	$sqlstmt = "SELECT	S.Service_Branch_ID,
											S.Service_Branch_Value
							FROM 		tblServiceBranch S  
							WHERE 	S.Active = 1 
							ORDER BY S.Service_Branch_Value";
?>