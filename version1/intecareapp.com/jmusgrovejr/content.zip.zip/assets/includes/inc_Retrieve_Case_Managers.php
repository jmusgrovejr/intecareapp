<?php
	$sqlstmt = "SELECT	C.Case_Manager_ID,
											C.Case_Manager_Name
							FROM 		tblCaseManagers C  
							WHERE 	C.Active = 1 
							ORDER BY C.Case_Manager_Name";
?>