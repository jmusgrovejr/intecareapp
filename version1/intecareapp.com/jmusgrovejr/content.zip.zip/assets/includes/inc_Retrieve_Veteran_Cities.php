<?php
	$sqlstmt = "SELECT	C.City_ID,
											C.City_Name
							FROM 		tblCity C  
							WHERE 	C.Active = 1 
							ORDER BY C.City_Name";
?>