<?php
	$event_id					 = 0;
	$event_title			 = '';
	$event_begin_date	 = '';
	$event_begin_time	 = '';
	$event_end_date		 = '';
	$event_end_time		 = '';
	$event_location		 = '';
	$event_description = '';
	$active						 = '';

	$selected_event_id = $_REQUEST['Event_ID'];

	if ($selected_event_id != "") {
		$sqlstmt = "SELECT	Event_ID, 
												Event_Title, 
												CONVERT(VARCHAR(10),Event_Begin_Date,110) AS Event_Begin_Date, 
												Event_Begin_Time, 
												CONVERT(VARCHAR(10),Event_End_Date,110) AS Event_End_Date, 
												Event_End_Time, 
												Event_Location, 
												Event_Description, 
												Active
							  FROM 		tblEventCalendar 
								WHERE 	Event_ID = " . $selected_event_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) {
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
				$event_id				 	 = $row['Event_ID'];
				$event_title			 = $row['Event_Title'];
				$event_begin_date	 = $row['Event_Begin_Date'];
				$event_begin_time	 = $row['Event_Begin_Time'];
				$event_end_date		 = $row['Event_End_Date'];
				$event_end_time		 = $row['Event_End_Time'];
				$event_location		 = $row['Event_Location'];
				$event_description = $row['Event_Description'];
				$active						 = $row['Active'];
			}
		}
	}
?>