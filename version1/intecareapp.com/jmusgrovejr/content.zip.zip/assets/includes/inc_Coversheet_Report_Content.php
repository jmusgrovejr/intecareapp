<?php
	$j = 5;
	
	if ($result = sqlsrv_query($conn, $sqlstmt)) {
		while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
			$objPHPExcel->getActiveSheet()->setCellValue('A' . $j, $row["Staff_First_Name"] . ' ' . $row["Staff_Last_Name"]);
			$objPHPExcel->getActiveSheet()->setCellValue('B' . $j, $row["County_Name"]);
			$objPHPExcel->getActiveSheet()->setCellValue('C' . $j, $row["Outreach_Location"]);
			$objPHPExcel->getActiveSheet()->setCellValue('D' . $j, $row["Outreach_Contact_Person"]);
			$objPHPExcel->getActiveSheet()->setCellValue('E' . $j, $row["Outreach_Contact_Phone"]);
			$objPHPExcel->getActiveSheet()->setCellValue('F' . $j, $row["Target_Population"]);
			$objPHPExcel->getActiveSheet()->setCellValue('G' . $j, $row["Outreach_Date"]);
			$objPHPExcel->getActiveSheet()->setCellValue('H' . $j, $row["Contact_Type_Name"]);
			$objPHPExcel->getActiveSheet()->setCellValue('I' . $j, $row["Referral_Number"]);
			$objPHPExcel->getActiveSheet()->setCellValue('J' . $j, $row["Enrollment_Number"]);
			$objPHPExcel->getActiveSheet()->setCellValue('K' . $j, $row["Notes"]);
	
			$j++;
		}
	}
?>