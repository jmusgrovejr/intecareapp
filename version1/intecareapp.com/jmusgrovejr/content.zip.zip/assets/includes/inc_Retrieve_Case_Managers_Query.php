<?php
	$case_manager_id	  = 0;
	$case_manager_name  = '';
	$case_manager_email = '';
	$active						  = '';

	$selected_case_manager_id = $_REQUEST['Case_Manager_ID'];

	if ($selected_case_manager_id != "") {
		$sqlstmt = "SELECT	Case_Manager_ID, 
												Case_Manager_Name, 
												Case_Manager_Email, 
												Active
							  FROM 		tblCaseManagers 
								WHERE 	Case_Manager_ID = " . $selected_case_manager_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
        $case_manager_id 	  = $row['Case_Manager_ID'];
        $case_manager_name  = $row['Case_Manager_Name'];
        $case_manager_email = $row['Case_Manager_Email'];
        $active						  = $row['Active'];
			}
		}
	}
?>