<?php
	$contact_type_id	 = 0;
	$contact_type_name = '';
	$active						 = '';

	$selected_contact_type_id = $_REQUEST['Contact_Type_ID'];

	if ($selected_contact_type_id != "") {
		$sqlstmt = "SELECT	Contact_Type_ID, 
												Contact_Type_Name, 
												Active
							  FROM 		tblContactType 
								WHERE 	Contact_Type_ID = " . $selected_contact_type_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$contact_type_id 	 = $row['Contact_Type_ID'];
				$contact_type_name = $row['Contact_Type_Name'];
				$active						 = $row['Active'];
			}
		}
	}
?>