﻿<div style="line-height:12px">&nbsp;</div>

<table cellspacing="3" cellpadding="5" width="100%" border="0">
	<tr>
		<td class="gr_title"><a href="main.php" class="gr_title">Home &nbsp;</a>
    <br />
    <div style="line-height:5px">&nbsp;</div>
    <hr width="100%" width="2" color="#FFF" /></td>
    </td>
  </tr>

	<tr>
  	<td><div style="line-height:15px">&nbsp;</div></td>
  </tr>
	<tr>
		<td class="gr_title" ><a class="gr_title" href="javascript:showonlyonev2('vetDiv', 'vetContentDiv');" >Veteran Records &nbsp;</a><a id="vetContentDiv" class="gr_title" href="javascript:showonlyonev2('vetDiv', 'vetContentDiv');" ><img src="assets/images/arrow-right.png" border="0" /></a>
		<br />
    <div style="line-height:5px">&nbsp;</div>
    <hr width="100%" width="2" color="#FFF" /></td>
  </tr>

  <tr>
    <td width="100%" colspan="2">
    <div class="newboxes-2" id="vetDiv" style="display:none;">
      <table width="100%" cellpadding="1" cellspacing="2" border="0">
      	<tr>
			  	<td>
          <div style="padding-left:20px; margin-top:-10px;">
            <a href="vet_view_list.php" class="nav_link">Review Veteran Records List</a><br />
            <a href="vet_record.php?t=c" class="nav_link">Create a Veteran Record</a><br />
            <a href="vet_search.php" class="nav_link">Edit a Veteran Record</a>
            <div style="line-height:12px">&nbsp;</div>
          </div>
         	</td>
        </tr>
      </table>
		</div>
    </td>
  </tr>

	<tr>
  	<td><div style="line-height:10px">&nbsp;</div></td>
  </tr>

	<tr>
		<td class="gr_title" ><a class="gr_title" href="javascript:showonlyonev2('resDiv', 'resContentDiv');" >Update Resource List &nbsp;</a><a id="resContentDiv" class="gr_title" href="javascript:showonlyonev2('resDiv', 'resContentDiv');" ><img src="assets/images/arrow-right.png" border="0" /></a>
		<br />
    <div style="line-height:5px">&nbsp;</div>
    <hr width="100%" width="2" color="#FFF" /></td>
  </tr>

  <tr>
    <td width="100%" colspan="2">
    <div class="newboxes-2" id="resDiv" style="display:none;">
      <table width="100%" cellpadding="1" cellspacing="2" border="0">
      	<tr>
			  	<td>
          <div style="padding-left:20px; margin-top:-10px;">
            <a href="res_view_list.php" class="nav_link">Review Resource List</a><br />
            <a href="res_record.php?t=c" class="nav_link">Add a Resource</a><br />
            <a href="res_search.php" class="nav_link">Edit a Resource</a>
            <div style="line-height:12px">&nbsp;</div>
          </div>
         	</td>
        </tr>
      </table>
		</div>
    </td>
  </tr>

	<tr>
  	<td><div style="line-height:10px">&nbsp;</div></td>
  </tr>

	<tr>
		<td class="gr_title" ><a class="gr_title" href="javascript:showonlyonev2('outDiv', 'outContentDiv');" >Update Outreach Record &nbsp;</a><a id="outContentDiv" class="gr_title" href="javascript:showonlyonev2('outDiv', 'outContentDiv');" ><img src="assets/images/arrow-right.png" border="0" /></a>
		<br />
    <div style="line-height:5px">&nbsp;</div>
    <hr width="100%" width="2" color="#FFF" /></td>
  </tr>

  <tr>
    <td width="100%" colspan="2">
    <div class="newboxes-2" id="outDiv" style="display:none;">
      <table width="100%" cellpadding="1" cellspacing="2" border="0">
      	<tr>
			  	<td>
          <div style="padding-left:20px; margin-top:-10px;">
            <a href="out_view_list.php" class="nav_link">Review Outreach List</a><br />
            <a href="out_record.php?t=c" class="nav_link">Add an Outreach Record</a><br />
            <a href="out_search.php" class="nav_link">Edit an Outreach Record</a>
            <div style="line-height:12px">&nbsp;</div>
          </div>
         	</td>
        </tr>
      </table>
		</div>
    </td>
  </tr>

	<tr>
  	<td><div style="line-height:15px">&nbsp;</div></td>
  </tr>

	<tr>
		<td class="gr_title"><a href="events.php" class="gr_title">Events &nbsp;</a>
    <br />
    <div style="line-height:5px">&nbsp;</div>
    <hr width="100%" width="2" color="#FFF" /></td>
    </td>
  </tr>

	<tr>
  	<td><div style="line-height:15px">&nbsp;</div></td>
  </tr>

  <tr>
    <td class="gr_title" ><a class="gr_title" href="javascript:showonlyonev2('reportDiv', 'reportContentDiv');" >Reports &nbsp;</a><a id="reportContentDiv" class="gr_title" href="javascript:showonlyonev2('reportDiv', 'reportContentDiv');" ><img src="assets/images/arrow-right.png" border="0" /></a>
    <br />
    <div style="line-height:5px">&nbsp;</div>
    <hr width="100%" width="2" color="#FFF" /></td>
  </tr>

  <tr>
    <td width="100%" colspan="2">
    <div class="newboxes-2" id="reportDiv" style="display:none;">
      <table width="100%" cellpadding="1" cellspacing="2" border="0">
        <tr>
          <td>
          <div style="padding-left:20px; margin-top:-10px;">
            <a href="rpt_referral_tracking.php" class="nav_link">Referral Tracking</a><br />
            <a href="rpt_outreach.php" class="nav_link">Outreach Tracking</a><br />
            <a href="rpt_referral.php" class="nav_link">Referral Reports</a><br />
            <!--<a href="rpt_coversheet.php" class="nav_link">SSVF Coversheet</a><br />
            <a href="rpt_open_ref.php?t=c" class="nav_link">Closed Referrals</a><br />
            <div style="line-height:12px">&nbsp;</div>-->
          </div>
          </td>
        </tr>
      </table>
    </div>
    </td>
  </tr>

  <tr>
    <td><div style="line-height:15px">&nbsp;</div></td>
  </tr>

	<?php if ($_SESSION['User_Type_ID'] == 1) { ?>
    <tr>
      <td class="copy_normal_nav_16">
      <div style="line-height:15px">&nbsp;</div>
      Admin Section
      <div style="line-height:10px">&nbsp;</div></td>
    </tr>

    <tr>
      <td class="gr_title" ><a class="gr_title" href="javascript:showonlyonev2('adminReportDiv', 'adminReportContentDiv');" >Reports &nbsp;</a><a id="adminReportContentDiv" class="gr_title" href="javascript:showonlyonev2('adminReportDiv', 'adminReportContentDiv');" ><img src="assets/images/arrow-right.png" border="0" /></a>
      <br />
      <div style="line-height:5px">&nbsp;</div>
      <hr width="100%" width="2" color="#FFF" /></td>
    </tr>
  
    <tr>
      <td width="100%" colspan="2">
      <div class="newboxes-2" id="adminReportDiv" style="display:none;">
        <table width="100%" cellpadding="1" cellspacing="2" border="0">
          <tr>
            <td>
            <div style="padding-left:20px; margin-top:-10px;">
              <a href="rpt_case_manager_peer.php" class="nav_link">Case Manager & Peer Mentor Referral Report</a><br />
              <a href="rpt_screen_not_enrolled.php?t=e" class="nav_link">Screen But Not Enrolled</a><br />
              <!--<a href="rpt_open_ref.php?t=o" class="nav_link">Open Referrals for Follow Up</a><br />
              <a href="rpt_open_ref.php?t=c" class="nav_link">Closed Referrals</a><br />
              <a href="rpt_open_ref.php?t=n" class="nav_link">Referrals Not Eligible</a><br />
              <a href="rpt_tot_clients.php?t=r" class="nav_link">Total Clients - Rapid Re-housing</a><br />
              <a href="rpt_tot_clients.php?t=p" class="nav_link">Total Clients – Prevention</a>
              <a href="rpt_tot_clients.php?t=c" class="nav_link">Total Clients by Case Manager and Subcontractor</a>
              <a href="rpt_screened_ne.php" class="nav_link">Screened not enrolled</a>
              <a href="rpt_outreach.php" class="nav_link">Outreach</a>
              <div style="line-height:12px">&nbsp;</div>-->
            </div>
            </td>
          </tr>
        </table>
      </div>
      </td>
    </tr>
  
    <tr>
      <td><div style="line-height:15px">&nbsp;</div></td>
    </tr>

    <tr>
      <td class="gr_title" ><a class="gr_title" href="javascript:showonlyonev2('tableDiv', 'tableContentDiv');" >Table Maintenance &nbsp;</a><a id="tableContentDiv" class="gr_title" href="javascript:showonlyonev2('tableDiv', 'tableContentDiv');" ><img src="assets/images/arrow-right.png" border="0" /></a>
      <br />
      <div style="line-height:5px">&nbsp;</div>
      <hr width="100%" width="2" color="#FFF" /></td>
    </tr>
  
    <tr>
      <td width="100%" colspan="2">
      <div class="newboxes-2" id="tableDiv" style="display:none;">
        <table width="100%" cellpadding="1" cellspacing="2" border="0">
          <tr>
            <td>
            <div style="padding-left:20px; margin-top:-10px;">
              <a href="manage_action.php" class="nav_link">Manage Action</a><br />
              <a href="manage_calendar_events.php" class="nav_link">Manage Calendar Events</a><br />
              <a href="manage_case_managers.php" class="nav_link">Manage Case Managers</a><br />
              <a href="manage_city.php" class="nav_link">Manage Cities</a><br />
              <a href="manage_contact_types.php" class="nav_link">Manage Contact Types</a><br />
              <a href="manage_county.php" class="nav_link">Manage Counties</a><br />
              <a href="manage_discharge_status.php" class="nav_link">Manage Discharge Status</a><br />
              <a href="manage_heard.php" class="nav_link">Manage Heard About Program</a><br />
              <a href="manage_housing_status.php" class="nav_link">Manage Housing Status</a><br />
              <a href="manage_hmis_review.php" class="nav_link">Manage HMIS Review</a><br />
              <a href="manage_main_content.php" class="nav_link">Manage Main Content</a><br />
              <a href="manage_resource_type.php" class="nav_link">Manage Resource Types</a><br />
              <a href="manage_service_branch.php" class="nav_link">Manage Service Branch</a><br />
              <a href="manage_service_time.php" class="nav_link">Manage Service Time</a><br />
              <a href="manage_users.php" class="nav_link">Manage Users</a><br />
              <a href="manage_user_types.php" class="nav_link">Manage User Types</a><br />
              <a href="manage_veteran_income.php" class="nav_link">Manage Veteran Income</a>
              <div style="line-height:12px">&nbsp;</div>
            </div>
            </td>
          </tr>
        </table>
      </div>
      </td>
    </tr>
  
    <tr>
      <td><div style="line-height:15px">&nbsp;</div></td>
    </tr>
  <?php } else {?>
    <tr>
      <td width="100%" colspan="2"><div class="newboxes-2" id="adminReportContentDiv" style="display:none;">&nbsp;</div></td>
    </tr>

    <tr>
      <td width="100%" colspan="2"><div class="newboxes-2" id="tableContentDiv" style="display:none;">&nbsp;</div></td>
    </tr>
  <?php } ?>

	<tr>
		<td class="gr_title"><a href="act_logout.php" class="gr_title">Log Out &nbsp;</a></td>
  </tr>
</table>

<div style="line-height:50px">&nbsp;</div>
	