<?php
	$sqlstmt = "SELECT	User_Type_ID, 
											User_Type_Desc, 
											Active
							FROM 		tblUserTypes 
							WHERE 	Active = 1
							ORDER BY User_Type_Desc";
?>