<?php
	$search_first_name_stmt				 = '';
	$search_last_name_stmt				 = '';
	$search_outreach_location_stmt = '';
	$search_outreach_date_stmt		 = '';
	$search_county_id_stmt				 = '';
	
	if ($_REQUEST['Search_Staff_First_Name'] != '') $search_first_name_stmt = " AND O.Staff_First_Name LIKE '%" . $_REQUEST['Search_Staff_First_Name'] . "%'";
	if ($_REQUEST['Search_Staff_Last_Name'] != '') $search_last_name_stmt = " AND O.Staff_Last_Name LIKE '%" . $_REQUEST['Search_Staff_Last_Name'] . "%'";
	if ($_REQUEST['Search_Outreach_Location'] != '') $search_outreach_location_stmt = " AND O.Outreach_Location LIKE '%" . $_REQUEST['Search_Outreach_Location'] . "%'";
	if ($_REQUEST['Search_Outreach_Date'] != '') $search_outreach_date_stmt = " AND O.Outreach_Date = '" . date('Y-m-d', strtotime($_REQUEST['Search_Outreach_Date'])) . "'";
	if ($_REQUEST['Search_County_ID'] != '') $search_county_id_stmt = " AND O.County_ID = " . $_REQUEST['Search_County_ID'];

	$sqlstmt = "SELECT	O.Outreach_ID,
											O.Staff_First_Name, 
											O.Staff_Last_Name,
											O.Outreach_Location, 
											CONVERT(VARCHAR(10),O.Outreach_Date,110) AS Outreach_Date, 
											CT.County_Name 
							FROM 		tblOutreach O LEFT OUTER JOIN tblCounty CT ON O.County_ID = CT.County_ID 
							WHERE 	1=1 " .
							$search_first_name_stmt .
							$search_last_name_stmt .
							$search_county_id_stmt . 
							$search_outreach_location_stmt . 
							$search_outreach_date_stmt . "
							ORDER BY O.Staff_Last_Name, O.Staff_First_Name";

	$params = array();
	$options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
	$stmt = sqlsrv_query( $conn, $sqlstmt , $params, $options );
	$row_count = sqlsrv_num_rows( $stmt );
?>