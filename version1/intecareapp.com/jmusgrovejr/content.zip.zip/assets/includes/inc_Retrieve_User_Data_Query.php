<?php
	$user_id 				 = 0;
	$user_type_id 	 = 0;
	$first_name 		 = "";
	$last_name 			 = "";
	$user_name			 = "";
	$user_password	 = "";
	$email_address 	 = "";
	$last_logon_date = "";
	$active 				 = "";
	
	$selected_user_id = $_REQUEST['User_ID'];

	if ($selected_user_id != "") {
		$sqlstmt = "SELECT	U.User_ID, 
												U.User_Type_ID,
												U.First_Name, 
												U.Last_Name, 
												U.User_Name, 
												U.User_Password, 
												U.Email_Address, 
												CONVERT(VARCHAR(10),U.Last_Logon_Date,110) AS Last_Logon_Date, 
												U.Active
								FROM 		tblUsers U
								WHERE 	User_ID = " . $selected_user_id;

		if ($result = sqlsrv_query($conn, $sqlstmt)) { 
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) { 
				$user_id 				 = $row['User_ID'];
				$user_type_id 	 = $row['User_Type_ID'];
				$first_name 		 = $row['First_Name'];
				$last_name 			 = $row['Last_Name'];
				$user_name 			 = $row['User_Name'];
				$user_password	 = $row['User_Password'];
				$email_address	 = $row['Email_Address'];
				$last_logon_date = $row['Last_Logon_Date'];
				$active 				 = $row['Active'];
			}
		}
	}

?>