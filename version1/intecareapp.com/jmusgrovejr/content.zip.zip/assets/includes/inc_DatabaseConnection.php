<?php
	$db_host = 'localhost';
	$db_user = 'gwc-ssvf';   //recommend using a lower privileged user
	$db_pwd = 'P@ss1234';
	$database = 'ssvf';
	
	$table = 'ssvf';

	$connectionInfo = array("UID" => $db_user, "PWD" => $db_pwd, "Database"=>$database); 
	$conn = sqlsrv_connect( $db_host, $connectionInfo);
?>
