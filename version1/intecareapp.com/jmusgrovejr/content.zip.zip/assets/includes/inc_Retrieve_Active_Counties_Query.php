<?php
	$sqlstmt = "SELECT	C.County_ID, 
											C.County_Name, 
											C.Active
							FROM 		tblCounty C 
							WHERE 	C.Active = 1
							ORDER BY C.County_Name";
?>