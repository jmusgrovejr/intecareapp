<?php
	$db_host = 'localhost';
	$db_user = 'gwc-ssvf';   //recommend using a lower privileged user
	$db_pwd = 'P@ss1234';
	$database = 'ssvf';
	
	$table = 'ssvf';

	$connectionInfo = array("UID" => $db_user, "PWD" => $db_pwd, "Database"=>$database); 
	$conn = sqlsrv_connect( $db_host, $connectionInfo);

	//$serach_begin_date_stmt = "";
	//$serach_end_date_stmt	= "";

	//$search_begin_date = date('Y/m/d', strtotime($begin_date));
	//$search_end_date = date('Y/m/d', strtotime($end_date));
	//$search_begin_date = date('Y-m-d', strtotime($begin_date));
	//$search_end_date = date('Y-m-d', strtotime($end_date));	
	//$serach_begin_date_stmt . 
	//$serach_end_date_stmt . "
	//WHERE  	1=1

	//if ($_REQUEST['Search_Begin_Date'] != '') $serach_begin_date_stmt = " AND V.Referral_CM_Date >= '" . $search_begin_date . "'";
	//if ($_REQUEST['Search_End_Date'] != '') $serach_end_date_stmt = " AND V.Referral_CM_Date <= '" . $search_end_date . "'";


	$sqlstmt = "SELECT 
												V.Veteran_Last_Name,
												V.Veteran_First_Name,
												V.Veteran_Address1,
												V.Veteran_Address2,
												V.Veteran_Zip_Code,
												V.Veteran_Phone,
												H.Housing_Status_Value,
												CONVERT(VARCHAR(10),V.Referral_CM_Date,110) AS Referral_CM_Date,
												CONVERT(VARCHAR(10),V.Initial_Appointment_Date,110) AS Initial_Appointment_Date,
												V.Appointment_Met_YN,
												V.Veteran_Enrolled, 
												V.Category_Level,
												C.Case_Manager_Name 
								FROM		tblVeterans V LEFT OUTER JOIN tblHousingStatus H ON V.Housing_Status_ID = H.Housing_Status_ID
										LEFT OUTER JOIN tblCaseManagers C ON V.Case_Manager_ID = C.Case_Manager_ID
								WHERE  	1=1
								AND V.Referral_CM_Date >= '" . $begin_date . "' 
								AND V.Referral_CM_Date < '" . $end_date . "'
								ORDER BY V.Referral_CM_Date DESC, V.Veteran_Last_Name, V.Veteran_First_Name";
?>