<?php
	$search_first_name_stmt = '';
	$search_last_name_stmt 	= '';
	$search_city_id_stmt 		= '';
	$search_city_other_stmt	= '';
	$search_county_id_stmt	= '';
	
	if ($_REQUEST['Search_Veteran_First_Name'] != '') $search_first_name_stmt = " AND V.Veteran_First_Name LIKE '%" . $_REQUEST['Search_Veteran_First_Name'] . "%'";
	if ($_REQUEST['Search_Veteran_Last_Name'] != '') $search_last_name_stmt = " AND V.Veteran_Last_Name LIKE '%" . $_REQUEST['Search_Veteran_Last_Name'] . "%'";
	if ($_REQUEST['Search_City_ID'] != '') $search_city_id_stmt = " AND V.City_ID = " . $_REQUEST['Search_City_ID'];
	if ($_REQUEST['Search_City_Other'] != '') $search_city_other_stmt = " AND V.City_Other LIKE '%" . $_REQUEST['Search_City_Other'] . "%'";
	if ($_REQUEST['Search_County_ID'] != '') $search_county_id_stmt = " AND V.County_ID = " . $_REQUEST['Search_County_ID'];

	$sqlstmt = "SELECT	V.Veteran_ID,
											V.Veteran_First_Name, 
											V.Veteran_Last_Name, 
											V.Veteran_Phone, 
											V.City_Other, 
											C.City_Name, 
											CT.County_Name 
							FROM 		tblVeterans V LEFT OUTER JOIN tblCity C ON V.City_ID = C.City_ID
																		LEFT OUTER JOIN tblCounty CT ON V.County_ID = CT.County_ID 
							WHERE 	1=1 " .
							$search_first_name_stmt .
							$search_last_name_stmt .
							$search_city_other_stmt .
							$search_city_id_stmt .
							$search_county_id_stmt . "
							ORDER BY V.Veteran_Last_Name, V.Veteran_First_Name";

	$params = array();
	$options =  array( "Scrollable" => SQLSRV_CURSOR_KEYSET );
	$stmt = sqlsrv_query( $conn, $sqlstmt , $params, $options );
	$row_count = sqlsrv_num_rows( $stmt );
?>