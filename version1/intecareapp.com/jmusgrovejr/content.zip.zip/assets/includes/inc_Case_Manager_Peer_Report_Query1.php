<?php
	$username="root";
	$password="SuperFly01!";
	$database="ssv";

	$link = mysql_connect('localhost',$username,$password);

	$sqlstmt_v = "SELECT 
												CONVERT(VARCHAR(10),V.Referral_CM_Date,110) AS Referral_CM_Date,
												CONVERT(VARCHAR(10),V.Initial_Appointment_Date,110) AS Initial_Appointment_Date,
												V.Veteran_Last_Name,
												V.Veteran_First_Name,
												V.Veteran_Phone,
												V.Veteran_Address1,
												V.Veteran_Address2,
												V.Veteran_Zip_Code,
												H.Housing_Status_Value,
												V.Appointment_Met_YN,
												V.Veteran_Enrolled, 
												V.Category_Level,
												C.Case_Manager_Name 
								FROM		tblVeterans V LEFT OUTER JOIN tblHousingStatus H ON V.Housing_Status_ID = H.Housing_Status_ID
										LEFT OUTER JOIN tblCaseManagers C ON V.Case_Manager_ID = C.Case_Manager_ID
								WHERE  	1=1
								//AND V.Referral_CM_Date >= '" . $begin_date->format('Y-m-d') . "' 
								//AND V.Referral_CM_Date < '" . $end_date->format('Y-m-d') . "' 
								ORDER BY V.Referral_CM_Date DESC, V.Veteran_Last_Name, V.Veteran_First_Name";
?>