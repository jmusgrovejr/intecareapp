
<div style="width:980px;">
<div style="line-height:50px">&nbsp;</div>

<div id="footer-1" class="copy_normal_nav_16">
  CONTACT US: Toll Free (855) 896-4345 | Email: <a href="mailto:ssvf@intecare.org" class="copy_normal_link_16">ssvf@intecare.org</a>
</div>

<div id="footer-2" class="copy_normal_nav_16">
  <a href="#" target="_blank"><img src="assets/images/email_logo.png" width="36" height="34" /></a> &nbsp;
  <a href="www.facebook.com" target="_blank"><img src="assets/images/facebook_logo.png" width="36" height="34" /></a>
</div>

<div class="nav_spacer">&nbsp;</div>
</div>
