<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<?php
	// Include the CKEditor class.
	include_once "ckeditor/ckeditor_php5.php";
	
	// Create a class instance.
	$CKEditor = new CKEditor();
	
	// Path to the CKEditor directory.
	$CKEditor->basePath = 'ckeditor/';

	// Replace all textarea elements with CKEditor.
	$CKEditor->replaceAll();

	// Set global configuration (used by every instance of CKEditor).
	$CKEditor->config['width'] = 1080;
	$CKEditor->config['height'] = 1000;

	// Change default textarea attributes.
	$CKEditor->textareaAttributes = array("cols" => 120, "rows" => 125);
?>

<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

  <title>Supportive Services for Veteran Families (SSVF)</title>
  <link href="assets/css/style.css" rel="stylesheet" type="text/css" />
  <link href="assets/css/menu.css" rel="stylesheet" type="text/css" />
  <link href="assets/css/menu_styles.css" rel="stylesheet" type="text/css" />
	<link href="assets/css/thickbox.css" rel="stylesheet" type="text/css" media="screen" />
	<link href="assets/css/jquery-ui.css" rel="stylesheet" type="text/css" media="screen" />
  
	<script type="text/javascript" src="assets/js/jquery-1.10.2.js"></script>
	<script type="text/javascript" src="assets/js/jquery-ui.js"></script>
	<script type="text/javascript" src="assets/js/jquery.maskedinput.js"></script>
	<script type="text/javascript" src="assets/js/ToggleLayers.js"></script>
	<script type="text/javascript" src="assets/js/checkvalues.js"></script>
	<script type="text/javascript" src="assets/js/popupWindow.js"></script>
	<script type="text/javascript" src="ckeditor/ckeditor.js"></script>
	<script type="text/javascript" src="assets/js/menu_jquery.js"></script>
	<script type="text/javascript" src="assets/js/thickbox-compressed.js"></script>

	<script type="text/javascript">
		$(function() {
			$( "#Initial_Contact_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Initial_Contact_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function() {
			$( "#Initial_Call_Back_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Initial_Call_Back_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function() {
			$( "#Referral_CM_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Referral_CM_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function() {
			$( "#Initial_Appointment_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Initial_Appointment_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function() {
			$( "#Exit_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Exit_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function() {
			$( "#Outreach_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Outreach_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function() {
			$( "#Search_Outreach_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Search_Outreach_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function() {
			$( "#Event_Begin_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Event_Begin_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function() {
			$( "#Event_End_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Event_End_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function() {
			$( "#Search_Begin_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Search_Begin_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function() {
			$( "#Search_End_Date" ).datepicker();
				$( "#anim" ).change(function() {
				$( "#Search_End_Date" ).datepicker( "option", "showAnim", "slideDown" );
			});
		});

		$(function(){
   		$("#Initial_Contact_Date").mask("99/99/9999");
   		$("#Initial_Call_Back_Date").mask("99/99/9999");
   		$("#Referral_CM_Date").mask("99/99/9999");
   		$("#Initial_Appointment_Date").mask("99/99/9999");
   		$("#Exit_Date").mask("99/99/9999");
   		$("#Outreach_Date").mask("99/99/9999");
   		$("#Search_Outreach_Date").mask("99/99/9999");
   		$("#Event_Begin_Date").mask("99/99/9999");
   		$("#Event_End_Date").mask("99/99/9999");
   		$("#Veteran_Phone").mask("999-999-9999? x99999");
   		$("#Other_Contact_Phone").mask("999-999-9999? x99999");
   		$("#Resource_Phone").mask("999-999-9999? x99999");
   		$("#Outreach_Contact_Phone").mask("999-999-9999? x99999");
   		$("#Referral_CM_Time").mask("99:99");
   		$("#Initial_Call_Back_Time").mask("99:99");
   		$("#Event_Begin_Time").mask("99:99");
   		$("#Event_End_Time").mask("99:99");
		});
	</script>

	<script type="text/javascript">
		CKEDITOR.replace( 'editor1',
		{
			toolbar : 'MyToolbar',
			uiColor : '#333'
		});
	</script>
</head>

