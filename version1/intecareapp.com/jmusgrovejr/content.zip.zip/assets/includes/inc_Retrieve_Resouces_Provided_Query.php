<?php
	$resource_name = "";

	$sqlstmt_r = "SELECT 	R.Resource_Name
								FROM		tblVeteransResourceTypesAssoc V, tblResourceTypes R
								WHERE  	V.Veteran_ID = " . $row["Veteran_ID"] . "
								AND			V.Resource_Type_ID = R.Resource_Type_ID
								ORDER BY R.Resource_Name";

	if ($result_r = sqlsrv_query($conn, $sqlstmt_r)) {
		while($row_r = sqlsrv_fetch_array($result_r, SQLSRV_FETCH_ASSOC)) {
			$resource_name .= $row_r["Resource_Name"] . '; ';
		}
	}
?>