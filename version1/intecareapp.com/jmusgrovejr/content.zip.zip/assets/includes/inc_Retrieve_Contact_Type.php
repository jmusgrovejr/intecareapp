<?php
	$sqlstmt = "SELECT	C.Contact_Type_ID,
											C.Contact_Type_Name
							FROM 		tblContactType C  
							WHERE 	C.Active = 1 
							ORDER BY C.Contact_Type_Name";
?>