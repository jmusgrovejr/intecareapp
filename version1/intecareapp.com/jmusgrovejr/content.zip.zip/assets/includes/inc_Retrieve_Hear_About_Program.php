<?php
	$sqlstmt = "SELECT	H.Hear_About_Program_ID,
											H.Hear_About_Program_Value
							FROM 		tblHearAboutProgram H  
							WHERE 	H.Active = 1 
							ORDER BY H.Hear_About_Program_Value";
?>