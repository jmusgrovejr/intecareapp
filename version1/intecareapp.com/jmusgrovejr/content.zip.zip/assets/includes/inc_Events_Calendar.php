<?php
	
	/* draws a calendar */
	function draw_calendar($month,$year,$events = array()){
		/* draw table */
		$calendar = '<table cellpadding="0" cellspacing="0" class="calendar">';

		/* table headings */
		$headings = array('Sun','Mon','Tues','Wed','Thurs','Fri','Sat');
		$calendar.= '<tr class="calendar-row"><td class="calendar-day-head">'.implode('</td><td class="calendar-day-head">',$headings).'</td></tr>';

		/* days and weeks vars now ... */
		$running_day = date('w',mktime(0,0,0,$month,1,$year));
		$days_in_month = date('t',mktime(0,0,0,$month,1,$year));
		$days_in_this_week = 1;
		$day_counter = 0;
		$dates_array = array();

		/* row for week one */
		$calendar.= '<tr class="calendar-row">';

		/* print "blank" days until the first of the current week */
		for($x = 0; $x < $running_day; $x++):
			$calendar.= '<td class="calendar-day-np">&nbsp;</td>';
			$days_in_this_week++;
		endfor;

		/* keep going with days.... */
		for($list_day = 1; $list_day <= $days_in_month; $list_day++):
			$calendar.= '<td class="calendar-day"><div style="position:relative;height:100%;">';

			/* add in the day number */
			$calendar.= '<div class="day-number">'.$list_day.'</div>';
				
			$event_day = $year.'-'.$month.'-'.$list_day;

			if(isset($events[$event_day])) {
				foreach($events[$event_day] as $event) {
					$calendar.= '<a href="event_details.php?EID=' . $event['Event_ID']. '&keepThis=true&TB_iframe=true&modal=true&height=340&width=550" title="Event - ' . $event['Event_Title'] . '" class="thickbox" id="event">' . $event['Event_Title'] . '</a><br /><div style="line-height:6px;">&nbsp;</div>';
				}
			}
			else {
				$calendar.= str_repeat('<p>&nbsp;</p>',2);
			}

			$calendar.= '</div></td>';

			if($running_day == 6):
				$calendar.= '</tr>';

				if(($day_counter+1) != $days_in_month):
					$calendar.= '<tr class="calendar-row">';
				endif;

				$running_day = -1;
				$days_in_this_week = 0;
			endif;

			$days_in_this_week++; $running_day++; $day_counter++;
		endfor;

		/* finish the rest of the days in the week */
		if($days_in_this_week < 8):
			for($x = 1; $x <= (8 - $days_in_this_week); $x++):
				$calendar.= '<td class="calendar-day-np">&nbsp;</td>';
			endfor;
		endif;

		/* final row */
		$calendar.= '</tr>';
	

		/* end the table */
		$calendar.= '</table>';

		/** DEBUG **/
		$calendar = str_replace('</td>','</td>'."\n",$calendar);
		$calendar = str_replace('</tr>','</tr>'."\n",$calendar);
	
		/* all done, return result */
		return $calendar;
	}

	function random_number() {
		srand(time());
		return (rand() % 7);
	}

	/* date settings */
	$month = (int) ($_GET['month'] ? $_GET['month'] : date('m'));
	$year = (int)  ($_GET['year'] ? $_GET['year'] : date('Y'));

	if (strlen($month) == 1) $month = '0' . $month;

	/* select month control */
	$select_month_control = '<select name="month" id="month" style="width:90px;">';

	for($x = 1; $x <= 12; $x++) {
		$select_month_control.= '<option value="'.$x.'"'.($x != $month ? '' : ' selected="selected"').'>'.date('F',mktime(0,0,0,$x,1,$year)).'</option>';
	}

	$select_month_control.= '</select>';

	/* select year control */
	$year_range = 7;
	$select_year_control = '<select name="year" id="year" style="width:70px;">';

	for($x = ($year-floor($year_range/2)); $x <= ($year+floor($year_range/2)); $x++) {
		$select_year_control.= '<option value="'.$x.'"'.($x != $year ? '' : ' selected="selected"').'>'.$x.'</option>';
	}

	$select_year_control.= '</select>';

	/* "next month" control */
	$next_month_link = '<a href="?month='.($month != 12 ? $month + 1 : 1).'&year='.($month != 12 ? $year : $year + 1).'" class="control">Next Month &gt;&gt;</a>';

	/* "previous month" control */
	$previous_month_link = '<a href="?month='.($month != 1 ? $month - 1 : 12).'&year='.($month != 1 ? $year : $year - 1).'" class="control">&lt;&lt; 	Previous Month</a>';

	/* bringing the controls together */
	$controls = '<form method="get">'.$select_month_control.$select_year_control.'&nbsp;<input type="submit" name="submit" value="Go" style="height:26px; margin-top:2px; cursor:pointer;" />&nbsp;&nbsp;&nbsp;&nbsp;'.	
	$previous_month_link.'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$next_month_link.' </form>';

	/* get all events for the given month */
	$events = array();
	$sqlstmt = "SELECT Event_ID, Event_Title, CONVERT(VARCHAR(10), Event_Begin_Date, 120) AS Event_Begin_Date FROM tblEventCalendar WHERE Event_Begin_Date LIKE '$year-$month%'";

	if ($result = sqlsrv_query($conn, $sqlstmt)) {
		while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
			$events[$row['Event_Begin_Date']][] = $row;
		}
	}

	echo '<h4 style="float:left; padding-right:30px;"><strong>'.date('F',mktime(0,0,0,$month,1,$year)).' '.$year.'</strong></h4>';
	echo '<div style="float:left;">'.$controls.'</div>';
	echo '<div style="clear:both;"></div>';
	echo draw_calendar($month,$year,$events);
	echo '<br /><br />';
?>