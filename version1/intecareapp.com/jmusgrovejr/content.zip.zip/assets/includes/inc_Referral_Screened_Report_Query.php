<?php
	$db_host = 'localhost';
	$db_user = 'gwc-ssvf';   //recommend using a lower privileged user
	$db_pwd = 'P@ss1234';
	$database = 'ssvf';
	
	$table = 'ssvf';

	$connectionInfo = array("UID" => $db_user, "PWD" => $db_pwd, "Database"=>$database); 
	$conn = sqlsrv_connect( $db_host, $connectionInfo);

	$serach_begin_date_stmt = "";
	$serach_end_date_stmt 	= "";
	$serach_county_id_stmt 	= "";

	$search_begin_date = date('Y-m-d', strtotime($begin_date));
	$search_end_date = date('Y-m-d', strtotime($end_date));
	
	if ($_REQUEST['Search_Begin_Date'] != '') $serach_begin_date_stmt = " AND V.Initial_Contact_Date >= '" . $search_begin_date . "'";
	if ($_REQUEST['Search_End_Date'] != '') $serach_end_date_stmt = " AND V.Initial_Contact_Date <= '" . $search_end_date . "'";
	if ($_REQUEST['Search_County_ID'] != '' && $_REQUEST['Search_County_ID'] != 'All') $search_county_id_stmt = " AND V.County_ID = " . $_REQUEST['Search_County_ID'];
	
	$sqlstmt = "SELECT 	V.Action_ID, 
											V.Veteran_ID, 
											V.Veteran_First_Name, 
											V.Veteran_Last_Name, 
											CONVERT(VARCHAR(10),V.Initial_Contact_Date,110) AS Initial_Contact_Date,
											V.No_Explain
							FROM		tblVeterans V
							WHERE  	V.Action_ID = 2
							AND			Veteran_Potentially_Eligible_YN = 'No'" .
							$serach_begin_date_stmt .
							$serach_end_date_stmt .
							$search_county_id_stmt . "
							ORDER BY V.Veteran_Last_Name, V.Veteran_First_Name";
?>