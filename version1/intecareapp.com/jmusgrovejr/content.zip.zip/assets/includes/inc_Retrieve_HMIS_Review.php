<?php
	$sqlstmt = "SELECT	H.HMIS_Review_ID,
											H.HMIS_Review_Value
							FROM 		tblHMISReview H  
							WHERE 	H.Active = 1 
							ORDER BY H.HMIS_Review_ID";
?>