<?php

	$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
	$objPHPExcel->getDefaultStyle()->getFont()->setSize(11); 

	$objPHPExcel->getActiveSheet()->getStyle('A1:M1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A1:M1')->getFont()->setBold(true);
 
	$objPHPExcel->getActiveSheet()->getStyle('A2:M2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A2:M2')->getFont()->setBold(true);

	$objPHPExcel->getActiveSheet()->getStyle('A3:M3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A3:M3')->getFont()->setBold(true);

	$objPHPExcel->getActiveSheet()->getStyle('A4:M4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A4:M4')->getFont()->setBold(true);
 
	$objPHPExcel->getActiveSheet()->setCellValue('A1', 'Case Manager & Peer Mentor Referral Report');
	$objPHPExcel->getActiveSheet()->setCellValue('H2', date('m/d/Y')); 
	$objPHPExcel->getActiveSheet()->setCellValue('A3', ' '); 

	$objPHPExcel->getActiveSheet()->mergeCells('A1:M1');#1F497D
	$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

	$objPHPExcel->getActiveSheet()->mergeCells('A2:M2');
	$objPHPExcel->getActiveSheet()->getStyle('A2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

	$objPHPExcel->getActiveSheet()->mergeCells('A3:M3');
	$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);
 
	$objPHPExcel->getActiveSheet()->setCellValue('A4', 'LAST NAME');  
	$objPHPExcel->getActiveSheet()->setCellValue('B4', 'FIRST NAME');  
	$objPHPExcel->getActiveSheet()->setCellValue('C4', 'ADDRESS 1');  
	$objPHPExcel->getActiveSheet()->setCellValue('D4', 'ADDRESS 2');  
	$objPHPExcel->getActiveSheet()->setCellValue('E4', 'ZIP CODE');  
	$objPHPExcel->getActiveSheet()->setCellValue('F4', 'PHONE');  
	$objPHPExcel->getActiveSheet()->setCellValue('G4', 'HOUSING STATUS');  
	$objPHPExcel->getActiveSheet()->setCellValue('H4', 'REFERRAL DATE');  
	$objPHPExcel->getActiveSheet()->setCellValue('I4', 'INITIAL APPOINTMENT DATE');  
	$objPHPExcel->getActiveSheet()->setCellValue('J4', 'APPOINTMENT MEET');  
	$objPHPExcel->getActiveSheet()->setCellValue('K4', 'VETERAN ENROLLED');  
	$objPHPExcel->getActiveSheet()->setCellValue('L4', 'CATEGORY LEVEL');  
	$objPHPExcel->getActiveSheet()->setCellValue('M4', 'CASE MANAGER');  

	$objPHPExcel->getDefaultStyle()->getFont()->setSize(10); 
?>