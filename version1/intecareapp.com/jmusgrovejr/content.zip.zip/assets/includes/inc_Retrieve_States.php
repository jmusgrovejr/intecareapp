<?php
	$sqlstmt = "SELECT	S.State_ID,
											S.State_Abbrev, 
											S.State_Name, 
											S.Active
							FROM 		tblStates S  
							WHERE 	S.Active = 1 
							ORDER BY S.State_Name";
?>