<?php
	$j = 4;
	
	if ($result_v = sqlsrv_query($conn, $sqlstmt_v)) {
		while($row_v = sqlsrv_fetch_array($result_v, SQLSRV_FETCH_ASSOC)) {
			$objPHPExcel->getActiveSheet()->setCellValue('A' . $j, $row_v["Referral_CM_Date"]);
			$objPHPExcel->getActiveSheet()->setCellValue('B' . $j, $row_v["Veteran_Last_Name"]);
			$objPHPExcel->getActiveSheet()->setCellValue('C' . $j, $row_v["Veteran_First_Name"]);
			$objPHPExcel->getActiveSheet()->setCellValue('D' . $j, $row_v["Veteran_Phone"]);
			$objPHPExcel->getActiveSheet()->setCellValue('E' . $j, $row_v["County_Name"]);
	
			if ($row_v["City_Other"] == '') $city = $row_v["City_Name"];
			else $city = $row_v["City_Other"];
	
			$objPHPExcel->getActiveSheet()->setCellValue('F' . $j, $city);
			$objPHPExcel->getActiveSheet()->setCellValue('G' . $j, $row_v["HMIS_Review_Value"]);
			
			$notes = '';
			$veteran_id = $row_v["Veteran_ID"];
			include 'assets/includes/inc_Retrieve_Documentation_Notes.php';
			
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$notes .= $row["Documentation_Note_Desc"] . '; ';
				}
			}
	
			$objPHPExcel->getActiveSheet()->setCellValue('H' . $j, $notes);
			$objPHPExcel->getActiveSheet()->setCellValue('I' . $j, $row_v["Veteran_Enrolled"]);
			$objPHPExcel->getActiveSheet()->setCellValue('J' . $j, $row_v["Other_Contact"]);
			$objPHPExcel->getActiveSheet()->setCellValue('K' . $j, 'Which Field?');
			$objPHPExcel->getActiveSheet()->setCellValue('L' . $j, 'Which Field?');

			$j++;
		}
	}
?>