<?php
	$sqlstmt = "SELECT	A.Action_ID,
											A.Action_Value
							FROM 		tblAction A  
							WHERE 	A.Active = 1 
							ORDER BY A.Action_ID";
?>