<?php
	$objPHPExcel->getDefaultStyle()->getFont()->setName('Calibri');
	$objPHPExcel->getDefaultStyle()->getFont()->setSize(11); 

	$objPHPExcel->getActiveSheet()->getStyle('A1:K1')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A1:K1')->getFont()->setBold(true);

	$objPHPExcel->getActiveSheet()->getStyle('A2:K2')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A2:K2')->getFont()->setBold(true);

	$objPHPExcel->getActiveSheet()->getStyle('A3:K3')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A3:K3')->getFont()->setBold(true);

	$objPHPExcel->getActiveSheet()->getStyle('A4:K4')->getFill()->setFillType(PHPExcel_Style_Fill::FILL_SOLID)->getStartColor()->setRGB('CCC0DA');
	$objPHPExcel->getActiveSheet()->getStyle('A4:K4')->getFont()->setBold(true);

	$objPHPExcel->getActiveSheet()->setCellValue('A1', 'OUTREACH TRACKING');
	$objPHPExcel->getActiveSheet()->setCellValue('A2', date('m/d/Y')); 
	$objPHPExcel->getActiveSheet()->setCellValue('A3', ' '); 

	$objPHPExcel->getActiveSheet()->mergeCells('A1:K1');#1F497D
	$objPHPExcel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

	$objPHPExcel->getActiveSheet()->mergeCells('A2:K2');
	$objPHPExcel->getActiveSheet()->getStyle('A2')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

	$objPHPExcel->getActiveSheet()->mergeCells('A3:K3');
	$objPHPExcel->getActiveSheet()->getStyle('A3')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER);

	$objPHPExcel->getActiveSheet()->setCellValue('A4', 'STAFF NAME');  
	$objPHPExcel->getActiveSheet()->setCellValue('B4', 'COMMUNITY');  
	$objPHPExcel->getActiveSheet()->setCellValue('C4', 'OUTREACH LOCATION');  
	$objPHPExcel->getActiveSheet()->setCellValue('D4', 'CONTACT PERSON');  
	$objPHPExcel->getActiveSheet()->setCellValue('E4', 'CONTACT PHONE');  
	$objPHPExcel->getActiveSheet()->setCellValue('F4', 'TARGET POPULATION');  
	$objPHPExcel->getActiveSheet()->setCellValue('G4', 'DATE OF CONTACT');  
	$objPHPExcel->getActiveSheet()->setCellValue('H4', 'TYPE OF CONTACT');  
	$objPHPExcel->getActiveSheet()->setCellValue('I4', '# OF REFERRALS');  
	$objPHPExcel->getActiveSheet()->setCellValue('J4', '# ENROLLED');  
	$objPHPExcel->getActiveSheet()->setCellValue('K4', 'NOTES');  

	$objPHPExcel->getDefaultStyle()->getFont()->setSize(10); 
?>