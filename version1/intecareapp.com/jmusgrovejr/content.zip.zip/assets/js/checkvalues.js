// JScript source code
function BE_Counter()  {  
	document.thisAdminForm.BE_Count.value = document.thisAdminForm.Blog_Excerpt.value.length;

	if (document.thisAdminForm.BE_Count.value > 140) {
		alert ('Max length has been reached.');
		document.thisAdminForm.Blog_Excerpt.value = document.thisAdminForm.Blog_Excerpt.value.substring(0,140);
	}
}

function HHL_Counter_1()  {  
	document.thisAdminForm.HHL_Count_1.value = document.thisAdminForm.Page_Hub_Header_1.value.length;

	if (document.thisAdminForm.HHL_Count_1.value > 150) {
		alert ('Max length has been reached.');
		document.thisAdminForm.Page_Hub_Header_1.value = document.thisAdminForm.Page_Hub_Header_1.value.substring(0,150);
	}
}

function HHL_Counter_2()  {  
	document.thisAdminForm.HHL_Count_2.value = document.thisAdminForm.Page_Hub_Header_2.value.length;

	if (document.thisAdminForm.HHL_Count_2.value > 150) {
		alert ('Max length has been reached.');
		document.thisAdminForm.Page_Hub_Header_2.value = document.thisAdminForm.Page_Hub_Header_2.value.substring(0,150);
	}
}

function HHL_Counter_3()  {  
	document.thisAdminForm.HHL_Count_3.value = document.thisAdminForm.Page_Hub_Header_3.value.length;

	if (document.thisAdminForm.HHL_Count_3.value > 150) {
		alert ('Max length has been reached.');
		document.thisAdminForm.Page_Hub_Header_3.value = document.thisAdminForm.Page_Hub_Header_3.value.substring(0,150);
	}
}

function HSL_Counter_1()  {  
	document.thisAdminForm.HSL_Count_1.value = document.thisAdminForm.Page_Hub_Sub_Header_1.value.length;

	if (document.thisAdminForm.HSL_Count_1.value > 150) {
		alert ('Max length has been reached.');
		document.thisAdminForm.Page_Hub_Sub_Header_1.value = document.thisAdminForm.Page_Hub_Sub_Header_1.value.substring(0,150);
	}
}

function HSL_Counter_2()  {  
	document.thisAdminForm.HSL_Count_2.value = document.thisAdminForm.Page_Hub_Sub_Header_2.value.length;

	if (document.thisAdminForm.HSL_Count_2.value > 150) {
		alert ('Max length has been reached.');
		document.thisAdminForm.Page_Hub_Sub_Header_2.value = document.thisAdminForm.Page_Hub_Sub_Header_2.value.substring(0,150);
	}
}

function HSL_Counter_3()  {  
	document.thisAdminForm.HSL_Count_3.value = document.thisAdminForm.Page_Hub_Sub_Header_3.value.length;

	if (document.thisAdminForm.HSL_Count_3.value > 150) {
		alert ('Max length has been reached.');
		document.thisAdminForm.Page_Hub_Sub_Header_3.value = document.thisAdminForm.Page_Hub_Sub_Header_3.value.substring(0,150);
	}
}

function CheckValues() {
	var errorMsg = "Must provide an answer. \n";
	var noAnswer = "";

	for (i=0; i<=5; i++) {
		if (document.evaluation.answer[i].checked) noAnswer = 1
	}

	if (noAnswer == "") {
		alert(errorMsg);
	}
	else {
		document.evaluation.submit();
	}
}

function SubmitForm() {
		window.location = document.selectForm.Admin_Tool.value;
}

function PrintReport (pgmName, org_id, toDate, fromDate) {
	var winleft = (screen.width - 930) / 2;
	var winUp = (screen.height - 500) / 2;
	var theURL;
	var Name;

	winProp = 'width=930,height=500,left='+winleft+',top='+winUp+',scrollbars=yes,resizable=yes';

	if (org_id != "") theURL = pgmName + '.php?org_id=' + org_id;
	else if (toDate != "") theURL = pgmName + '.php?to_date=' + toDate + '&from_date=' + fromDate;
	else theURL = pgmName + '.php';

	if (pgmName == 'rpt_undup_provider_excel') theURL = pgmName + '.php?r=' + org_id;
	if (pgmName == 'rpt_missing_2011_excel' || pgmName == 'rpt_contract_2011_excel') theURL = pgmName + '.php?GCT_ID=' + org_id;
	if (pgmName == 'geo_provider_search_excel') theURL = pgmName + '.php?search_city_name=' + org_id + '&search_zip_code=' + toDate + '&search_county_id=' + fromDate;
	if (pgmName == 'rpt_historical_excel') theURL = pgmName + '.php?' + org_id + '&to_date=' + toDate + '&from_date=' + fromDate;

	Name = 'PrintReport'

	Win = window.open(theURL, Name, winProp);
	Win.window.focus();
}

function PrintSpecialtyReport (pgmName, city, zip, county, gender, disorders, treatments) {
	var winleft = (screen.width - 930) / 2;
	var winUp = (screen.height - 500) / 2;
	var theURL;
	var Name;

	winProp = 'width=930,height=500,left='+winleft+',top='+winUp+',scrollbars=yes,resizable=yes';

	if (pgmName == 'search_location_disorders_excel') theURL = pgmName + '.php?search_city_name=' + city + '&search_zip_code=' + zip + '&search_county_id=' + county + '&hedis=' + gender + '&And_Disorders=' + disorders + '&And_Treatments=' + treatments;
	else if (pgmName == 'search_location_outpatient_excel') theURL = pgmName + '.php?search_city_name=' + city + '&search_zip_code=' + zip + '&search_county_id=' + county + '&hedis=' + gender + '&And_Outpatient=' + disorders;
	else if (pgmName == 'search_location_mro_excel') theURL = pgmName + '.php?search_city_name=' + city + '&search_zip_code=' + zip + '&search_county_id=' + county + '&hedis=' + gender + '&And_MRO=' + disorders;
	else theURL = pgmName + '.php?search_city_name=' + city + '&search_zip_code=' + zip + '&search_county_id=' + county + '&Gender=' + gender + '&And_Disorders=' + disorders + '&And_Treatments=' + treatments ;

	Name = 'PrintReport'

	Win = window.open(theURL, Name, winProp);
	Win.window.focus();
}

function LaunchSubmit() {
	if (document.launch.User_ID.value == "") {
		alert("Please select a user.");
		return false;
	}
	
	document.launch.submit();
}

function ManagerSubmit() {
	if (document.manager.button.value == "tr") {
		if (document.manager.Supervisor_User_ID.value == "") {
			alert("Please select a manager.");
			return false;
		}
	}
	
	if (document.manager.button.value == "ur") {
		if (document.manager.User_ID.value == "") {
			alert("Please select a user.");
			return false;
		}
	}

	document.manager.submit();
}

function CheckAdminValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.First_Name.value == "") errorMsg = errorMsg + "\tFirst Name \n";
	if (document.thisAdminForm.Last_Name.value == "") errorMsg = errorMsg + "\tLast Name \n";
	if (document.thisAdminForm.User_Name.value == "") errorMsg = errorMsg + "\tUser Name \n";

	if (document.thisAdminForm.User_ID.value == 0) {
		if (document.thisAdminForm.User_Password.value == "") errorMsg = errorMsg + "\tPassword \n";
	}
	if (document.thisAdminForm.Email_Address.value == "") errorMsg = errorMsg + "\tEmail Address \n";

	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckUpload() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

alert('in cu');
	if (document.userForm.Upload_File_Name.value == "") errorMsg = errorMsg + "\tUpload File \n";

	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckActionValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Action_Value.value == "") errorMsg = errorMsg + "\tAction Value \n";

	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

CheckActionValues
function CheckCalendarEventsValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Event_Title.value == "") errorMsg = errorMsg + "\tEvent Title \n";
	if (document.thisAdminForm.Event_Begin_Date.value == "") errorMsg = errorMsg + "\tEvent Begin Date \n";

	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckEventsValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Action_Value.value == "") errorMsg = errorMsg + "\tAction Value \n";

	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function SearchRptOutreach() {
	var errorMsg = "Please enter search criteria. \n";
	var length = errorMsg.length;

	if (document.rptOutreach.Search_Begin_Date.value == "" && document.rptOutreach.Search_End_Date.value == "" && document.rptOutreach.Search_County_ID.value == "" && document.rptOutreach.Search_User_ID.value == "") errorMsg = errorMsg + " ";

	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.rptOutreach.submit();
	}
}

function SearchRptCaseManagerPeer() {
	var errorMsg = "Please enter search criteria dates. \n";
	var length = errorMsg.length;

	if (document.rptCaseManagerPeer.Search_Begin_Date.value == "" && document.rptCaseManagerPeer.Search_End_Date.value == "") errorMsg = errorMsg + " ";

	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.rptCaseManagerPeer.submit();
	}
}

function SearchRptScreenNotEnrolled() {
	var errorMsg = "Please enter search criteria dates. \n";
	var length = errorMsg.length;

	if (document.rptScreenNotEnrolled.Search_Begin_Date.value == "" && document.rptScreenNotEnrolled.Search_End_Date.value == "") errorMsg = errorMsg + " ";

	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.rptScreenNotEnrolled.submit();
	}
}


function SearchRptCoversheet() {
	var errorMsg = "Reporting Month and Year are both required. \n";
	var length = errorMsg.length;

	if (document.rptCoversheet.Search_Reporting_Month.value == "" || document.rptCoversheet.Search_Reporting_Year.value == "") errorMsg = errorMsg + " ";

	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.rptCoversheet.submit();
	}
}

function DeleteCompany(ca) {
	if (confirm('Are you sure you want to delete Company ' + ca + ' and all Users and Saved Data associated with this Company?')) window.location = "act_delete_company.php?CA=" + ca;
}

function CheckCaseManagerValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Case_Manager_Name.value == "") errorMsg = errorMsg + "\tCase Manager Name \n";
	if (document.thisAdminForm.Case_Manager_Email.value == "") errorMsg = errorMsg + "\tCase Manager Email \n";

	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckCityValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.City_Name.value == "") errorMsg = errorMsg + "\tCity Name \n";
	if (document.thisAdminForm.County_ID.value == "0") errorMsg = errorMsg + "\tCounty Name \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckCountyValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.County_Name.value == "") errorMsg = errorMsg + "\tCounty Name \n";
	if (document.thisAdminForm.County_Code.value == "") errorMsg = errorMsg + "\tCounty Code \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckContactTypeValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Contact_Type_Name.value == "") errorMsg = errorMsg + "\tContact Type Name \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckResourceTypeValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Resource_Name.value == "") errorMsg = errorMsg + "\tResource Name \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckDischargeStatusValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Discharge_Status_Name.value == "") errorMsg = errorMsg + "\tDischarge Status Name \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckHearAboutProgramValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Hear_About_Program_Value.value == "") errorMsg = errorMsg + "\tHear About Program Value \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckHMISReviewValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.HMIS_Review_Value.value == "") errorMsg = errorMsg + "\tHMIS Review Value \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckServiceTimeValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Service_Time_Value.value == "") errorMsg = errorMsg + "\tService Time Value \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckServiceBranchValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Service_Branch_Value.value == "") errorMsg = errorMsg + "\tService Branch Value \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckHousingStatusValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Housing_Status_Value.value == "") errorMsg = errorMsg + "\tHousing Status Value \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckUserTypeValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.User_Type_Desc.value == "") errorMsg = errorMsg + "\tUser Type Name \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function CheckVeteranIncomeValues() {
	var errorMsg = "The following fields are required: \n";
	var length = errorMsg.length;

	if (document.thisAdminForm.Veteran_Income_Amount.value == "") errorMsg = errorMsg + "\tVeteran Income Amount \n";
	if (errorMsg.length > length) {
		alert(errorMsg);
	}
	else {
		document.thisAdminForm.submit();
	}
}

function DeleteRecord(pgmname, idname, idtable) {
	var idvalue = eval('document.thisAdminForm.' + idname + '.value');
	var tablevalue = eval('document.thisAdminForm.' + idtable + '.value');

	if (pgmname == 'act_admin_users') {
		pgmname = 'act_users';
		returnvalue = '&return=admin_users';
	}
	else if (pgmname == 'act_users') {
		returnvalue = '&return=users';
	}
	else if (idtable == 'cl_sponsors') {
		returnvalue = '&return=cl_sponsors';
	}
	else {
		returnvalue = '';
	}
	
	if (confirm('Are you sure you want to delete this record?')) window.location = pgmname + ".php?Function_Type=D&" + idname + "=" + idvalue + "&" + idtable + "=" + tablevalue + returnvalue;
}

function EmailNotification(idname, abbrev) {
	var idvalue = eval('document.thisAdminForm.' + idname + '.value');

	if (confirm('Are you sure you want to send an email notification to this user?')) window.location = "email_notification.php?" + idname + "=" + idvalue + "&Company_Abbrev=" + abbrev + "&return=company_users";
}

function DescCounter() {
	document.thisAdminForm.Desc_Count.value = document.thisAdminForm.Campaign_Desc.value.length;
}

function QuizQuestionCounter() {
	document.thisAdminForm.Desc_Count.value = document.thisAdminForm.Quiz_Question.value.length;
}

function QuizTagLineCounter() {
	document.thisAdminForm.TagLine_Count.value = document.thisAdminForm.Quiz_Tag_Line.value.length;
}

function CheckLocation() {
	var numObj = document.getElementById("Location_ID");
	var num = numObj.value;
	
	if (num == 0) {
		alert("Please select a Location.");
		return false
	}
}

function confirmLaunch() {
	answer = confirm('Are you sure you want to launch the Campaign?'); 
	
	if (answer) document.thisAdminForm.submit();
	else return false;
}

function checkLen(x,y,next) {
	if (y.length==x.maxLength) {
   	document.getElementById(next).focus();
  }
}

function checkEntryLen(x) {
	if (x > 250) {
		alert("Max length for Teaser is 250 characters.");
   	document.getElementById(Comments).focus();
		return false;
	}
	
	return true;
}

function checkField (fldName) {
	var fld = eval('document.userForm.' + fldName + '.value');
	var org_fld = eval('document.userForm.' + fldName + '_Original.value');

	if (fld == org_fld) document.getElementsByName(fldName)[0].value = '';

}
