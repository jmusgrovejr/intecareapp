function showonlyonev2(thechosenone, switchImgTag) {
	var newboxes = document.getElementsByTagName("div");
	var imageEle = document.getElementById(switchImgTag);

	document.getElementById('vetContentDiv').innerHTML = '<img src="assets/images/arrow-right.png">'
	document.getElementById('resContentDiv').innerHTML = '<img src="assets/images/arrow-right.png">'
	document.getElementById('outContentDiv').innerHTML = '<img src="assets/images/arrow-right.png">'
	document.getElementById('reportContentDiv').innerHTML = '<img src="assets/images/arrow-right.png">'
	document.getElementById('adminReportContentDiv').innerHTML = '<img src="assets/images/arrow-right.png">'
	document.getElementById('tableContentDiv').innerHTML = '<img src="assets/images/arrow-right.png">'

	for(var x=0; x<newboxes.length; x++) {
		name = newboxes[x].getAttribute("class");
		if (name == 'newboxes-2') {
			if (newboxes[x].id == thechosenone) {
				if (newboxes[x].style.display == 'block') {
					newboxes[x].style.display = 'none';
				}
				else {
					newboxes[x].style.display = 'block';
					imageEle.innerHTML = '<img src="assets/images/arrow-down.png">';
				}
			}
			else {
				newboxes[x].style.display = 'none';
			}
		}
	}

}

function showonlyone_2(thechosenone, switchImgTag, userType) {
	var newboxes = document.getElementsByTagName("div");
	var imageEle = document.getElementById(switchImgTag);

	document.getElementById('contactContentDiv').innerHTML = '<img src="assets/images/arrow-right-black.png">'
	document.getElementById('docContentDiv').innerHTML = '<img src="assets/images/arrow-right-black.png">'
	if (userType == 1) document.getElementById('admContentDiv').innerHTML = '<img src="assets/images/arrow-right-black.png">'
	
	for(var x=0; x<newboxes.length; x++) {
		name = newboxes[x].getAttribute("class");
		if (name == 'newboxes-3') {
			if (newboxes[x].id == thechosenone) {
				if (newboxes[x].style.display == 'block') {
					newboxes[x].style.display = 'none';
				}
				else {
					newboxes[x].style.display = 'block';
					imageEle.innerHTML = '<img src="assets/images/arrow-down-black.png">';
				}
			}
			else {
				newboxes[x].style.display = 'none';
			}
		}
	}

}

function showonlyonev3(thechosenone, switchImgTag) {
	var newboxes = document.getElementsByTagName("div");
	var imageEle = document.getElementById(switchImgTag);

	document.getElementById('photosDiv').innerHTML = '<img src="assets/images/arrow-right.png">'
	document.getElementById('documentsDiv').innerHTML = '<img src="assets/images/arrow-right.png">'

	for(var x=0; x<newboxes.length; x++) {
		name = newboxes[x].getAttribute("class");
		if (name == 'newboxes-2') {
			if (newboxes[x].id == thechosenone) {
				if (newboxes[x].style.display == 'block') {
					newboxes[x].style.display = 'none';
				}
				else {
					newboxes[x].style.display = 'block';
					imageEle.innerHTML = '<img src="assets/images/arrow-down.png">';
				}
			}
			else {
				newboxes[x].style.display = 'none';
			}
		}
	}

}

