<?php
	include 'assets/includes/inc_Session.php';

	$veteran_income_id = $_REQUEST["Veteran_Income_ID"];
	$function_type 	 	 = $_REQUEST["Function_Type"];
	$type						 	 = '';
	$values				 	 	 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblVeteranIncome WHERE Veteran_Income_ID = " . $veteran_income_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblVeteranIncome (
															Veteran_Income_Amount, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Veteran_Income_Amount"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Veteran_Income_ID) as ID FROM tblVeteranIncome";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$veteran_income_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblVeteranIncome 
									SET 	 Veteran_Income_Amount = '" . str_replace("'", "''", $_REQUEST["Veteran_Income_Amount"]) . "', 
												 Active						 		 = "  . $_REQUEST["Active"] . "
									WHERE  Veteran_Income_ID	 	 = "  . $veteran_income_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Veteran_Income_ID=' . $veteran_income_id;
	}
?>

<script>
	alert("Veteran Income has been <?php echo($type) ?>");
	window.location = "manage_veteran_income.php<?php echo $values; ?>";
</script>