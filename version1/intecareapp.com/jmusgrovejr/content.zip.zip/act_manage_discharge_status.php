<?php
	include 'assets/includes/inc_Session.php';

	$discharge_status_id = $_REQUEST["Discharge_Status_ID"];
	$function_type 			 = $_REQUEST["Function_Type"];
	$type								 = '';
	$values				 			 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblDischargeStatus WHERE Discharge_Status_ID = " . $discharge_status_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblDischargeStatus (
															Discharge_Status_Name, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Discharge_Status_Name"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Discharge_Status_ID) as ID FROM tblDischargeStatus";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$discharge_status_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblDischargeStatus 
									SET 	 Discharge_Status_Name = '" . str_replace("'", "''", $_REQUEST["Discharge_Status_Name"]) . "', 
												 Active						 		 = "  . $_REQUEST["Active"] . "
									WHERE  Discharge_Status_ID	 = "  . $discharge_status_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Discharge_Status_ID=' . $discharge_status_id;
	}
?>

<script>
	alert("Discharge Status has been <?php echo($type) ?>");
	window.location = "manage_discharge_status.php<?php echo $values; ?>";
</script>