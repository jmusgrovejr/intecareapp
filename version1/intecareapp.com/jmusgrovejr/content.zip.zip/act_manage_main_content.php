<?php
	include 'assets/includes/inc_Session.php';

	$main_content_id	 		 = $_REQUEST["Main_Content_ID"];
	$values 			 = '';
	
	//Update existing provider
	$sqlstmt = "UPDATE tblMainContent 
							SET 	 Main_Content			 = '" . str_replace("'", "''", $_REQUEST["Main_Content"]) . "', 
										 Last_Updated_By	 = '" . $_SESSION["First_Name"] . ' ' . $_SESSION["Last_Name"] . "', 
										 Last_Updated_Date = '" . date('Y-m-d') . "'
							WHERE  Main_Content_ID	 =  " . $main_content_id;

	sqlsrv_query($conn, $sqlstmt);
		
	$values = '?Main_Content_ID=' . $main_content_id;
?>

<script>
	alert("Main Content has been edited.");
	window.location = "manage_main_content.php<?php echo $values; ?>";
</script>