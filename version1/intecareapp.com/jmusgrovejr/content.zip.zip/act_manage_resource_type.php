<?php
	include 'assets/includes/inc_Session.php';

	$resource_type_id	= $_REQUEST["Resource_Type_ID"];
	$function_type 		= $_REQUEST["Function_Type"];
	$type					 		= '';
	$values 			 		= '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblResourceTypes WHERE Resource_Type_ID = " . $resource_type_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblResourceTypes (
															Resource_Name, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Resource_Name"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Resource_Type_ID) as ID FROM tblResourceTypes";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$resource_type_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblResourceTypes 
									SET 	 Resource_Name 		= '" . str_replace("'", "''", $_REQUEST["Resource_Name"]) . "', 
												 Active						= "  . $_REQUEST["Active"] . "
									WHERE  Resource_Type_ID	= "  . $resource_type_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Resource_Type_ID=' . $resource_type_id;
	}
?>

<script>
	alert("Resource Type has been <?php echo($type) ?>");
	window.location = "manage_resource_type.php<?php echo $values; ?>";
</script>