<?php
	include 'assets/includes/inc_Session.php';

	$county_id	 	 = $_REQUEST["County_ID"];
	$function_type = $_REQUEST["Function_Type"];
	$type					 = '';
	$values 			 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblCounty WHERE County_ID = " . $county_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblCounty (
															County_Name, 
															County_Code, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["County_Name"]) . "', '" 
														. $_REQUEST['County_Code'] . "', "
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(County_ID) as ID FROM tblCounty";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$county_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblCounty 
									SET 	 County_Name = '" . str_replace("'", "''", $_REQUEST["County_Name"]) . "', 
												 County_Code = '" . $_REQUEST["County_Code"] . "', 
												 Active			 =  " . $_REQUEST["Active"] . "
									WHERE  County_ID	 =  " . $county_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?County_ID=' . $county_id;
	}
?>

<script>
	alert("County has been <?php echo($type) ?>");
	window.location = "manage_county.php<?php echo $values; ?>";
</script>