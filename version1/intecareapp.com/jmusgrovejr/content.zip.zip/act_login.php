<?php
	// Make a connection to the database
	session_start();
	include 'assets/includes/inc_DatabaseConnection.php';

	$message = "";
	
	if ($_REQUEST["User_Login_ID"] != "" and $_REQUEST["User_Password"] != "") {
		// this code retrieves the data
		$sqlstmt = "SELECT U.User_ID, U.First_Name, U.Last_Name, UT.User_Type_Desc, UT.User_Type_ID, UT.User_Type_Desc, U.User_Password, U.Email_Address 
								FROM 	 tblUsers U, tblUserTypes UT
								WHERE  U.User_Type_ID	 = UT.User_Type_ID
								AND		 U.User_Name 		 = '" . $_REQUEST["User_Login_ID"] . "' 
								AND 	 U.User_Password = '" . $_REQUEST["User_Password"] . "' 
								AND 	 U.Active				 = 1";

		if ($result = sqlsrv_query($conn, $sqlstmt)) {
			while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
				$_SESSION["First_Name"] 		= $row['First_Name'];
				$_SESSION["Last_Name"] 			= $row['Last_Name'];
				$_SESSION["User_ID"] 				= $row['User_ID'];
				$_SESSION["Email_Address"] 	= $row['Email_Address'];
				$_SESSION["User_Type_ID"] 	= $row['User_Type_ID'];
				$_SESSION["User_Type_Desc"] = $row['User_Type_Desc'];
			}
		}

		$_SESSION["User_Login_ID"] = $_REQUEST["User_Login_ID"];
		$_SESSION["User_Password"] = $_REQUEST["User_Password"];

		if ($_SESSION["First_Name"] != "") {
			if ($_REQUEST['Veteran_ID'] == '') $page = 'main.php';
			else $page = 'vet_record.php?Veteran_ID=' . $_REQUEST['Veteran_ID'] . '&t=e';

			/* Update logon date for user */
			$sqlstmt = "UPDATE tblUsers
									SET Last_Logon = '" . date('Y-m-d') . "'
									WHERE User_ID  = " . $_SESSION["User_ID"];

			sqlsrv_query($conn, $sqlstmt);
?>
			<script>
        window.location = "<?php echo $page ?>"
      </script>
<?php
		}
		else {
?>
			<form name="act_login" id="act_login" action="index.php" method="post">
      <input type="hidden" name="msg" value="Invalid Username and/or Password." />
      <input type="hidden" name="User_Login_ID" value="<?php echo($_REQUEST["User_Login_ID"]) ?>" />
      <input type="hidden" name="User_Password" value="<?php echo($_REQUEST["User_Password"]) ?>" />
      <input type="hidden" name="vid" value="<?php echo($_REQUEST["Veteran_ID"]) ?>" />
			</form>

			<script>
				document.act_login.submit();
			</script>
<?php
		}
	}
	else {
?>
    <form name="act_login" id="act_login" action="index.php" method="post">
    <input type="hidden" name="msg" value="Username and Password are both required." />
    <input type="hidden" name="User_Login_ID" value="<?php echo($_REQUEST["User_Login_ID"]) ?>" />
    <input type="hidden" name="User_Password" value="<?php echo($_REQUEST["User_Password"]) ?>" />
    <input type="hidden" name="vid" value="<?php echo($_REQUEST["Veteran_ID"]) ?>" />
    </form>

    <script>
      document.act_login.submit();
    </script>
<?php
	}

	sqlsrv_close( $conn );
?>

