<?php
	include 'assets/includes/inc_Session.php';

	$case_manager_id	 	 = $_REQUEST["Case_Manager_ID"];
	$function_type = $_REQUEST["Function_Type"];
	$type					 = '';
	$values 			 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblCaseManagers WHERE Case_Manager_ID = " . $case_manager_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblCaseManagers (
															Case_Manager_Name, 
															Case_Manager_Email, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Case_Manager_Name"]) . "', '" 
														. str_replace("'", "''", $_REQUEST["Case_Manager_Email"]) . "', "
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Case_Manager_ID) as ID FROM tblCaseManagers";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$case_manager_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblCaseManagers 
									SET 	 Case_Manager_Name  = '" . str_replace("'", "''", $_REQUEST["Case_Manager_Name"]) . "', 
												 Case_Manager_Email = '" . str_replace("'", "''", $_REQUEST["Case_Manager_Email"]) . "',
												 Active						  = "  . $_REQUEST["Active"] . "
									WHERE  Case_Manager_ID	  = "  . $case_manager_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Case_Manager_ID=' . $case_manager_id;
	}
?>

<script>
	alert("Case Manager has been <?php echo($type) ?>");
	window.location = "manage_case_managers.php<?php echo $values; ?>";
</script>