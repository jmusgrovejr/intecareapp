<?php
	session_start();

	//set session empty
	session_destroy();
?>

<html>
<head>
	<meta HTTP-EQUIV="Refresh" CONTENT="0; URL=index.php">
</head>
</html>
