<?php
	include 'assets/includes/inc_Session.php';

	$housing_status_id = $_REQUEST["Housing_Status_ID"];
	$function_type 	 	 = $_REQUEST["Function_Type"];
	$type							 = '';
	$values				 		 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblHousingStatus WHERE Housing_Status_ID = " . $housing_status_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblHousingStatus (
															Housing_Status_Value, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Housing_Status_Value"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Housing_Status_ID) as ID FROM tblHousingStatus";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$housing_status_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblHousingStatus 
									SET 	 Housing_Status_Value = '" . str_replace("'", "''", $_REQUEST["Housing_Status_Value"]) . "', 
												 Active						 		= "  . $_REQUEST["Active"] . "
									WHERE  Housing_Status_ID	 	= "  . $housing_status_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Housing_Status_ID=' . $housing_status_id;
	}
?>

<script>
	alert("Housing Status has been <?php echo($type) ?>");
	window.location = "manage_housing_status.php<?php echo $values; ?>";
</script>