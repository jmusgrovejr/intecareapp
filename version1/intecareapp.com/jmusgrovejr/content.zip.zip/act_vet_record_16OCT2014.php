<?php
	include 'assets/includes/inc_Session.php';

	date_default_timezone_set('America/Indianapolis');

	$veteran_id = $_REQUEST["Veteran_ID"];
	$function_type = $_REQUEST["Function_Type"];

	if ($function_type == "D") {
		//Delete existing contact_type
		$sqlstmt = "DELETE FROM tblVeterans WHERE Veteran_ID = " . $veteran_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($_REQUEST['Nunber_In_House'] == '') $_REQUEST['Nunber_In_House'] = 'NULL';
		if ($_REQUEST['Category_Level'] == '') $_REQUEST['Category_Level'] = 'NULL';

		if ($_REQUEST['Initial_Contact_Date'] != '') {
			$date = strtotime($_REQUEST['Initial_Contact_Date']);
			$_REQUEST['Initial_Contact_Date'] = "'" . date('Y-m-d', $date) . "'";
		}
		else {
			$_REQUEST['Initial_Contact_Date'] = 'NULL';
		}

		if ($_REQUEST['Initial_Call_Back_Date'] != '') {
			$date = strtotime($_REQUEST['Initial_Call_Back_Date']);
			$_REQUEST['Initial_Call_Back_Date'] = "'" . date('Y-m-d', $date) . "'";
		}
		else {
			$_REQUEST['Initial_Call_Back_Date'] = 'NULL';
		}

		if ($_REQUEST['Referral_CM_Date'] != '') {
			$date = strtotime($_REQUEST['Referral_CM_Date']);
			$_REQUEST['Referral_CM_Date'] = "'" . date('Y-m-d', $date) . "'";
		}
		else {
			$_REQUEST['Referral_CM_Date'] = 'NULL';
		}

		if ($_REQUEST['Initial_Appointment_Date'] != '') {
			$date = strtotime($_REQUEST['Initial_Appointment_Date']);
			$_REQUEST['Initial_Appointment_Date'] = "'" . date('Y-m-d', $date) . "'";
		}
		else {
			$_REQUEST['Initial_Appointment_Date'] = 'NULL';
		}

		if ($_REQUEST['Exit_Date'] != '') {
			$date = strtotime($_REQUEST['Exit_Date']);
			$_REQUEST['Exit_Date'] = "'" . date('Y-m-d', $date) . "'";
		}
		else {
			$_REQUEST['Exit_Date'] = 'NULL';
		}

		if ($function_type == "I") {
			//Insert new contact_type
			$sqlstmt = "INSERT INTO tblVeterans (
															Discharge_Status_ID, 
															HMIS_Review_ID, 
															Action_ID, 
															City_ID, 
															County_ID, 
															Service_Branch_ID, 
															Housing_Status_ID, 
															Hear_About_Program_ID, 
															Case_Manager_ID, 
															Veteran_First_Name, 
															Veteran_Middle_Initial, 
															Veteran_Last_Name, 
															Veteran_Address1, 
															Veteran_Address2, 
															Veteran_Zip_Code, 
															Veteran_Phone, 
															Other_Contact, 
															Other_Contact_Phone, 
															City_Other, 
															Number_In_House, 
															Initial_Contact_Date, 
															Initial_Call_Back_Date, 
															Live_Answer_YN, 
															Initial_Call_Back_Time, 
															HUDVASH_Referral, 
															Doc_Review, 
															Doc_Review_Other, 
															Housing_Status_Notes, 
															Need_Assitance_YN, 
															Veteran_Service_Time, 
															Veteran_Monthly_Income, 
															Veteran_Potentially_Eligible_YN, 
															Referral_CM_Date, 
															Referral_CM_Time, 
															Initial_Appointment_Date, 
															Appointment_Met_YN, 
															Veteran_Enrolled, 
															Category_Level, 
															No_Explain, 
															Veteran_Active_Program, 
															Veteran_Exited_Program, 
															Exit_Date, 
															Insert_By, 
															Insert_Date, 
															Edit_By, 
															Edit_Date) 
									VALUES (" . $_REQUEST['Discharge_Status_ID'] . ", "
														. $_REQUEST['HMIS_Review_ID'] . ", "
														. $_REQUEST['Action_ID'] . ", "
														. $_REQUEST['City_ID'] . ", "
														. $_REQUEST['County_ID'] . ", "
														. $_REQUEST['Service_Branch_ID'] . ", "
														. $_REQUEST['Housing_Status_ID'] . ", "
														. $_REQUEST['Hear_About_Program_ID'] . ", "
														. $_REQUEST['Case_Manager_ID'] . ", '"
														.	str_replace("'", "''", $_REQUEST["Veteran_First_Name"]) . "', '" 
														.	str_replace("'", "''", $_REQUEST["Veteran_Middle_Initial"]) . "', '" 
														.	str_replace("'", "''", $_REQUEST["Veteran_Last_Name"]) . "', '" 
														.	str_replace("'", "''", $_REQUEST["Veteran_Address1"]) . "', '" 
														.	str_replace("'", "''", $_REQUEST["Veteran_Address2"]) . "', '" 
														.	$_REQUEST["Veteran_Zip_Code"] . "', '"
														.	$_REQUEST["Veteran_Phone"] . "', '"
														.	str_replace("'", "''", $_REQUEST["Other_Contact"]) . "', '"
														.	$_REQUEST["Other_Contact_Phone"] . "', '"
														. str_replace("'", "''", $_REQUEST["City_Other"]) . "', " 
														. $_REQUEST["Number_In_House"] . ", " 
														. $_REQUEST["Initial_Contact_Date"] . ", " 
														. $_REQUEST["Initial_Call_Back_Date"] . ", '" 
														. $_REQUEST["Live_Answer_YN"] . "', '" 
														. $_REQUEST["Initial_Call_Back_Time"] . "', '" 
														. $_REQUEST["HUDVASH_Referral"] . "', '" 
														. $_REQUEST["Doc_Review"] . "', '" 
														. str_replace("'", "''", $_REQUEST["Doc_Review_Other"]) . "', '" 
														. str_replace("'", "''", $_REQUEST["Housing_Status_Notes"]) . "', '" 
														. $_REQUEST["Need_Assitance_YN"] . "', '" 
														. str_replace("'", "''", $_REQUEST["Veteran_Service_Time"]) . "', '" 
														. str_replace("'", "''", $_REQUEST["Veteran_Monthly_Income"]) . "', '" 
														. $_REQUEST["Veteran_Potentially_Eligible_YN"] . "', " 
														. $_REQUEST["Referral_CM_Date"] . ", '" 
														. $_REQUEST["Referral_CM_Time"] . "', " 
														. $_REQUEST["Initial_Appointment_Date"] . ", '" 
														. $_REQUEST["Appointment_Met_YN"] . "', '" 
														. $_REQUEST["Veteran_Enrolled"] . "', " 
														. $_REQUEST["Category_Level"] . ", '" 
														. str_replace("'", "''", $_REQUEST["No_Explain"]) . "', '" 
														. $_REQUEST["Veteran_Active_Program"] . "', '" 
														. $_REQUEST["Veteran_Exited_Program"] . "', " 
														. $_REQUEST["Exit_Date"] . ", '" 
														. $_SESSION["First_Name"] . ' ' . $_SESSION["Last_Name"] . "', '"
														. date('Y-m-d') . "', '"
														. $_SESSION["First_Name"] . ' ' . $_SESSION["Last_Name"] . "', '"
														. date('Y-m-d') . "')";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Veteran_ID) as ID FROM tblVeterans";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$veteran_id = $row['ID'];
				}
			}
		}
		else {
			//Update existing contact_type
			$sqlstmt = "UPDATE tblVeterans 
									SET 	Discharge_Status_ID 						=  " . $_REQUEST['Discharge_Status_ID'] . ",
												HMIS_Review_ID 				 					=  " . $_REQUEST['HMIS_Review_ID'] . ", 
												Action_ID 				 							=  " . $_REQUEST['Action_ID'] . ", 
												City_ID 				 								=  " . $_REQUEST['City_ID'] . ", 
												County_ID 				 							=  " . $_REQUEST['County_ID'] . ", 
												Service_Branch_ID 				 			=  " . $_REQUEST['Service_Branch_ID'] . ", 
												Housing_Status_ID 				 			=  " . $_REQUEST['Housing_Status_ID'] . ", 
												Hear_About_Program_ID 				 	=  " . $_REQUEST['Hear_About_Program_ID'] . ", 
												Case_Manager_ID 				 				=  " . $_REQUEST['Case_Manager_ID'] . ", 
												Veteran_First_Name 				 			= '" . str_replace("'", "''", $_REQUEST["Veteran_First_Name"]) . "', 
												Veteran_Middle_Initial 					= '" . str_replace("'", "''", $_REQUEST["Veteran_Middle_Initial"]) . "', 
												Veteran_Last_Name 					 		= '" . str_replace("'", "''", $_REQUEST["Veteran_Last_Name"]) . "', 
												Veteran_Address1	 					 		= '" . str_replace("'", "''", $_REQUEST["Veteran_Address1"]) . "', 
												Veteran_Address2	 					 		= '" . str_replace("'", "''", $_REQUEST["Veteran_Address2"]) . "', 
												Veteran_Zip_Code 								= '" . $_REQUEST["Veteran_Zip_Code"] . "', 
												Veteran_Phone		 								= '" . $_REQUEST["Veteran_Phone"] . "', 
												Other_Contact 									= '" . str_replace("'", "''", $_REQUEST["Other_Contact"]) . "', 
												Other_Contact_Phone 				 		= '" . $_REQUEST['Other_Contact_Phone'] . "', 
												City_Other 											= '" . str_replace("'", "''", $_REQUEST["City_Other"]) . "', 
												Number_In_House 								=  " . $_REQUEST["Number_In_House"] . ", 
												Initial_Contact_Date 						=  " . $_REQUEST["Initial_Contact_Date"] . ", 
												Initial_Call_Back_Date 					=  " . $_REQUEST["Initial_Call_Back_Date"] . ", 
												Live_Answer_YN 									= '" . $_REQUEST["Live_Answer_YN"] . "', 
												Initial_Call_Back_Time 					= '" . $_REQUEST["Initial_Call_Back_Time"] . "', 
												HUDVASH_Referral 								= '" . str_replace("'", "''", $_REQUEST["HUDVASH_Referral"]) . "', 
												Doc_Review 											= '" . $_REQUEST["Doc_Review"] . "', 
												Doc_Review_Other 								= '" . str_replace("'", "''", $_REQUEST["Doc_Review_Other"]) . "', 
												Housing_Status_Notes 						= '" . str_replace("'", "''", $_REQUEST["Housing_Status_Notes"]) . "', 
												Need_Assitance_YN 							= '" . $_REQUEST["Need_Assitance_YN"] . "', 
												Veteran_Service_Time						= '" . $_REQUEST["Veteran_Service_Time"] . "', 
												Veteran_Monthly_Income					= '" . $_REQUEST["Veteran_Monthly_Income"] . "', 
												Veteran_Potentially_Eligible_YN = '" . $_REQUEST["Veteran_Potentially_Eligible_YN"] . "', 
												Referral_CM_Date								=  " . $_REQUEST["Referral_CM_Date"] . ", 
												Referral_CM_Time 								= '" . $_REQUEST["Referral_CM_Time"] . "', 
												Initial_Appointment_Date 				=  " . $_REQUEST["Initial_Appointment_Date"] . ", 
												Appointment_Met_YN 							= '" . $_REQUEST["Appointment_Met_YN"] . "', 
												Veteran_Enrolled 								= '" . $_REQUEST["Veteran_Enrolled"] . "', 
												Category_Level									=  " . $_REQUEST["Category_Level"] . ", 
												No_Explain											= '" . str_replace("'", "''", $_REQUEST["No_Explain"]) . "', 
												Veteran_Active_Program					= '" . $_REQUEST["Veteran_Active_Program"] . "', 
												Veteran_Exited_Program					= '" . $_REQUEST["Veteran_Exited_Program"] . "', 
												Exit_Date												=  " . $_REQUEST["Exit_Date"] . ", 
												Edit_By													= '" . $_SESSION["First_Name"] . ' ' . $_SESSION["Last_Name"] . "', 
												Edit_Date												= '" . date('Y-m-d') . "' 
									WHERE Veteran_ID 							 				=  " . $veteran_id;

			sqlsrv_query($conn, $sqlstmt);
		}

		if ($_REQUEST['Documentation_Note_Desc'] != '') {
			$sqlstmt = "INSERT INTO tblDocumentationNotes (
															Veteran_ID, 
															User_ID, 
															Documentation_Note_Desc, 
															Note_Date_Time) 
									VALUES (" . $veteran_id . ", "
														. $_SESSION['User_ID'] . ", '"
														. str_replace("'", "''", $_REQUEST["Documentation_Note_Desc"]) . "', '"
														. date('Y-m-d H:i:s') . "')";

			sqlsrv_query($conn, $sqlstmt);
		}

		if ($_REQUEST['Administrative_Note_Desc'] != '') {
			$sqlstmt = "INSERT INTO tblAdministrativeNotes (
															Veteran_ID, 
															User_ID, 
															Administrative_Note_Desc, 
															Note_Date_Time) 
									VALUES (" . $veteran_id . ", "
														. $_SESSION['User_ID'] . ", '"
														. str_replace("'", "''", $_REQUEST["Administrative_Note_Desc"]) . "', '"
														. date('Y-m-d H:i:s') . "')";

			sqlsrv_query($conn, $sqlstmt);
		}

		// manage resources
		$sqlstmt = "DELETE FROM tblVeteransResourceTypesAssoc WHERE Veteran_ID = " . $veteran_id;

		sqlsrv_query($conn, $sqlstmt);

		if ($_REQUEST['Resource_Type_ID'] != '') {
			$res_values = $_REQUEST['Resource_Type_ID'];

			foreach ($res_values as $item) {
				$sqlstmt = "INSERT INTO tblVeteransResourceTypesAssoc (Veteran_ID, Resource_Type_ID) VALUES (" . $veteran_id . ", " . $item . ")";

				sqlsrv_query($conn, $sqlstmt);
			}
		}
	}
?>

<script>
	alert("Veteran Information has been saved.");
	window.location = "vet_record.php?Veteran_ID=<?php echo $veteran_id; ?>&t=e";
</script>