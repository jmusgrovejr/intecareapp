<?php
	include 'assets/includes/inc_Session.php';

	$contact_type_id	 	 = $_REQUEST["Contact_Type_ID"];
	$function_type = $_REQUEST["Function_Type"];
	$type					 = '';
	$values 			 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblContactType WHERE Contact_Type_ID = " . $contact_type_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblContactType (
															Contact_Type_Name, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Contact_Type_Name"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);
	
			$sqlstmt = "SELECT MAX(Contact_Type_ID) as ID FROM tblContactType";

			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$contact_type_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblContactType 
									SET 	 Contact_Type_Name = '" . str_replace("'", "''", $_REQUEST["Contact_Type_Name"]) . "', 
												 Active						 = "  . $_REQUEST["Active"] . "
									WHERE  Contact_Type_ID	 = "  . $contact_type_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Contact_Type_ID=' . $contact_type_id;
	}
?>

<script>
	alert("Contact Type has been <?php echo($type) ?>");
	window.location = "manage_contact_types.php<?php echo $values; ?>";
</script>