<?php
	include 'assets/includes/inc_Session.php';

	$city_id	 		 = $_REQUEST["City_ID"];
	$function_type = $_REQUEST["Function_Type"];
	$type					 = '';
	$values 			 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblCity WHERE City_ID = " . $city_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblCity (
															County_ID, 
															City_Name, 
															Active) 
									VALUES (" . $_REQUEST['County_ID'] . ", '"
														. str_replace("'", "''", $_REQUEST["City_Name"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(City_ID) as ID FROM tblCity";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$city_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblCity 
									SET 	 County_ID =  " . $_REQUEST["County_ID"] . ", 
												 City_Name = '" . str_replace("'", "''", $_REQUEST["City_Name"]) . "', 
												 Active		 =  " . $_REQUEST["Active"] . "
									WHERE  City_ID	 =  " . $city_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?City_ID=' . $city_id;
	}
?>

<script>
	alert("City has been <?php echo($type) ?>");
	window.location = "manage_city.php<?php echo $values; ?>";
</script>