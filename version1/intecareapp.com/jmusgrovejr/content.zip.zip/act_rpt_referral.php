<?php
	//header("Content-type: application/vnd.ms-excel");
	//header("Content-Disposition: attachment; filename=excel.xls");

	set_time_limit (0);
	$begin_date = $_REQUEST['Search_Begin_Date'];
	$end_date 	= $_REQUEST['Search_End_Date'];

	require_once 'PHPExcel/Classes/PHPExcel.php'; 
	require_once 'PHPExcel/Classes/PHPExcel/IOFactory.php';  

	// Create new PHPExcel object 
	$objPHPExcel = new PHPExcel();  
 
	/************************************************************************** 
	* Create a first sheet, representing referral counts								      *
	**************************************************************************/ 
	$objPHPExcel->setActiveSheetIndex(0);

	// include the column headers	
	include 'assets/includes/inc_PHPExcel_Referral_Sources_Headers.php';

	// retrieve the outreach records
	include 'assets/includes/inc_Referral_Sources_Report_Query.php';

	// include the report content
	include 'assets/includes/inc_Referral_Sources_Report_Content.php';

	// Rename sheet
	$objPHPExcel->getActiveSheet()->setTitle('REFERRAL SOURCES');  

	// Create a new worksheet, after the default sheet 
	$objPHPExcel->createSheet();  
	
	/************************************************************************** 
	* Add some data to the second sheet, screened but not referrred			      *
	**************************************************************************/ 
	$objPHPExcel->setActiveSheetIndex(1); 

	// include the column headers	
	include 'assets/includes/inc_PHPExcel_Referral_Screened_Headers.php';

	// retrieve the active providers
	$provider_active = 1;
	$provider_type = 'A';
	include 'assets/includes/inc_Referral_Screened_Report_Query.php';

	// include the report content
	include 'assets/includes/inc_Referral_Screened_Report_Content.php';

	// Rename 2nd sheet (ADDS)
	$objPHPExcel->getActiveSheet()->setTitle('REFERRAL-SCREENED-NOT ENROLLED');  

	// Create a new worksheet, after the default sheet 
	$objPHPExcel->createSheet();  
	
	// Redirect output to a client's web browser (Excel5) 
	header('Content-Type: application/vnd.ms-excel'); 
	header('Content-Disposition: attachment;filename="name_of_file.xls"'); 
	header('Cache-Control: max-age=0'); 
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5'); 
	$objWriter->save('php://output');

	$file_created = 'Y';
//exit();
?>
<script>
	window.location = "rpt_outreach.php";
</script>