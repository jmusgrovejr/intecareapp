<?php
	//header("Content-type: application/vnd.ms-excel");
	//header("Content-Disposition: attachment; filename=excel.xls");

	set_time_limit (0);

	if ($_REQUEST['Search_Reporting_Year'] != "All") {
	    $begin_date = date_create($_REQUEST['Search_Reporting_Year'] . '/' . $_REQUEST['Search_Reporting_Month'] . '/01');
	}
	else {
	    $begin_date = "All";
	}

	if ($_REQUEST['Search_Reporting_Month'] == 12) {
		$next_month = 1;
		$year 			= $_REQUEST['Search_Reporting_Year'] + 1;
	}
	else {
		$next_month = $_REQUEST['Search_Reporting_Month'] + 1;
		$year 			= $_REQUEST['Search_Reporting_Year'];
	}

	if ($_REQUEST['Search_Reporting_Month'] == "All") {
	   $end_date = "All"
	}
	else {
	   $end_date		= date_create($year . '/' . $next_month . '/01');
	}

	//date_add($end_date, date_interval_create_from_date_string('1 month'));

	require_once 'PHPExcel/Classes/PHPExcel.php'; 
	require_once 'PHPExcel/Classes/PHPExcel/IOFactory.php';  

	// Create new PHPExcel object 
	$objPHPExcel = new PHPExcel();  
 
	/************************************************************************** 
	* Create a first sheet, representing cenpantico active providers data     *
	**************************************************************************/ 
	$objPHPExcel->setActiveSheetIndex(0);

	// include the column headers	
	include 'assets/includes/inc_PHPExcel_Referral_Tracking_Headers.php';

	// retrieve the outreach records
	include 'assets/includes/inc_Referral_Tracking_Report_Query.php';

	// include the report content
	include 'assets/includes/inc_Referral_Tracking_Report_Content.php';

	// Rename sheet
	if ($begin_date = 'All') {
	    $objPHPExcel->getActiveSheet()->setTitle($begin_date->format('M') . ' ' . $_REQUEST['Search_Reporting_Year']); 
	else {
	    $objPHPExcel->getActiveSheet()->setTitle('All');	
	} 

	// Create a new worksheet, after the default sheet 
	$objPHPExcel->createSheet();  
	
	// Redirect output to a client's web browser (Excel5) 
	header('Content-Type: application/vnd.ms-excel'); 
	header('Content-Disposition: attachment;filename="name_of_file.xls"'); 
	header('Cache-Control: max-age=0'); 
	$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel5'); 
	$objWriter->save('php://output');

	$file_created = 'Y';
//exit();
?>
<script>
	window.location = "rpt_outreach.php";
</script>