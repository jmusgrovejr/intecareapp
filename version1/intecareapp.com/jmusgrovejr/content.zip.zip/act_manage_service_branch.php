<?php
	include 'assets/includes/inc_Session.php';

	$service_branch_id = $_REQUEST["Service_Branch_ID"];
	$function_type 	 = $_REQUEST["Function_Type"];
	$type						 = '';
	$values				 	 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblServiceBranch WHERE Service_Branch_ID = " . $service_branch_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblServiceBranch (
															Service_Branch_Value, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Service_Branch_Value"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Service_Branch_ID) as ID FROM tblServiceBranch";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$service_branch_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblServiceBranch 
									SET 	 Service_Branch_Value = '" . str_replace("'", "''", $_REQUEST["Service_Branch_Value"]) . "', 
												 Active						 	= "  . $_REQUEST["Active"] . "
									WHERE  Service_Branch_ID	 	= "  . $service_branch_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Service_Branch_ID=' . $service_branch_id;
	}
?>

<script>
	alert("Service Branch has been <?php echo($type) ?>");
	window.location = "manage_service_branch.php<?php echo $values; ?>";
</script>