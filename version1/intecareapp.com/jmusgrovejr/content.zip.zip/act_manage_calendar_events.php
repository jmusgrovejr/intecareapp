<?php
	include 'assets/includes/inc_Session.php';

	$event_id			 = $_REQUEST["Event_ID"];
	$function_type = $_REQUEST["Function_Type"];
	$type					 = '';
	$values 			 = '';
	
	if ($function_type == "D") {
		$type = 'Deleted.';

		//Delete existing provider
		$sqlstmt = "DELETE FROM tblEventCalendar WHERE Event_ID = " . $event_id;

		sqlsrv_query($conn, $sqlstmt);
	}
	else {
		if ($_REQUEST['Event_Begin_Date'] != '') {
			$date = strtotime($_REQUEST['Event_Begin_Date']);
			$_REQUEST['Event_Begin_Date'] = "'" . date('Y-m-d', $date) . "'";
		}
		else {
			$_REQUEST['Event_Begin_Date'] = 'NULL';
		}

		if ($_REQUEST['Event_End_Date'] != '') {
			$date = strtotime($_REQUEST['Event_End_Date']);
			$_REQUEST['Event_End_Date'] = "'" . date('Y-m-d', $date) . "'";
		}
		else {
			$_REQUEST['Event_End_Date'] = 'NULL';
		}

		if ($function_type == "I") {
			$type = 'Added';

			//Insert new provider
			$sqlstmt = "INSERT INTO tblEventCalendar (
															Event_Title, 
															Event_Begin_Date, 
															Event_Begin_Time, 
															Event_End_Date, 
															Event_End_Time, 
															Event_Location, 
															Event_Description, 
															Active) 
									VALUES ('". str_replace("'", "''", $_REQUEST["Event_Title"]) . "', " 
														. $_REQUEST["Event_Begin_Date"] . ", '" 
														. $_REQUEST["Event_Begin_Time"] . "', " 
														. $_REQUEST["Event_End_Date"] . ", '" 
														. $_REQUEST["Event_End_Time"] . "', '" 
														. str_replace("'", "''", $_REQUEST["Event_Location"]) . "', '" 
														. str_replace("'", "''", $_REQUEST["Event_Description"]) . "', " 
														. $_REQUEST["Active"] . ")";

			sqlsrv_query($conn, $sqlstmt);

			$sqlstmt = "SELECT MAX(Event_ID) as ID FROM tblEventCalendar";
	
			if ($result = sqlsrv_query($conn, $sqlstmt)) {
				while($row = sqlsrv_fetch_array($result, SQLSRV_FETCH_ASSOC)) {
					$event_id = $row['ID'];
				}
			}
		}
		else {
			$type = 'Edited';

			//Update existing provider
			$sqlstmt = "UPDATE tblEventCalendar 
									SET 	 Event_Title			 = '" . str_replace("'", "''", $_REQUEST["Event_Title"]) . "', 
												 Event_Begin_Date	 =  " . $_REQUEST["Event_Begin_Date"] . ", 
												 Event_Begin_Time	 = '" . $_REQUEST["Event_Begin_Time"] . "', 
												 Event_End_Date		 =  " . $_REQUEST["Event_End_Date"] . ", 
												 Event_End_Time		 = '" . $_REQUEST["Event_End_Time"] . "', 
												 Event_Location		 = '" . str_replace("'", "''", $_REQUEST["Event_Location"]) . "', 
												 Event_Description = '" . str_replace("'", "''", $_REQUEST["Event_Description"]) . "', 
												 Active						 = "  . $_REQUEST["Active"] . "
									WHERE  Event_ID	  			 = "  . $event_id;

			sqlsrv_query($conn, $sqlstmt);
		}
		
		$values = '?Event_ID=' . $event_id;
	}
?>

<script>
	alert("Event has been <?php echo($type) ?>");
	window.location = "manage_calendar_events.php<?php echo $values; ?>";
</script>